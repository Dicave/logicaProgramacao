// ------------------------------------------------------------------------------------------------------
// all js
// ------------------------------------------------------------------------------------------------------

function post_onload() {
	ryi.editor_init_done = false;
	// onunload hide please wait

	// ----------------------------------------------------------------------------------------------------
	if (window.addEventListener) { // gecko
		window.addEventListener( 'beforeunload', ryi.hide_pleasewaitlayer, false );
	} else if (window.attachEvent) { // ie
		window.onbeforeunload = ryi.hide_pleasewaitlayer;
	}
	// einde onunload hide please wait
	// ----------------------------------------------------------------------------------------------------

  if ( document.getElementById('cookiewarning') ) {
    ryi.init_cookiewarning();
  }
  
  if ( document.getElementById('info_container') ) {
    ryi.init_info();
  }


  var infoHeight = document.getElementById('info_container').offsetHeight;
  infoHeight += document.getElementById('info_container_bar').offsetHeight;
  document.getElementById('content_container').style.bottom = infoHeight + 'px';

  var buttonsHeight = document.getElementById('button-bar').offsetHeight;
  document.getElementById('content_container').style.top = buttonsHeight + 'px';

  if ( document.getElementById('editor') ) {
    ryi.init();
  } else {
    RYI_set_ads();
  }

}

function onresize() {
  if ( typeof(ryi) != 'undefined' && typeof(ryi.redraw_editor) == 'function' ) {
    ryi.redraw_editor();
    RYI_set_ads();
  }
}

ryi.show_pleasewaitlayer = function() {
  document.getElementById('pleasewaitlayer').style.display = 'block';
}

ryi.hide_pleasewaitlayer = function() {
  document.getElementById('pleasewaitlayer').style.display = 'none';
}


ryi.show_infocontainer = function() {
  document.getElementById('info_container').className = '';
  setTimeout(ryi.create_infocontainer,100);
  createCookie('RYI_SHOW_INFO_TEXT','yes',365);
}

ryi.create_infocontainer = function() {
  document.getElementById('info_container').style.display = 'block';
  document.getElementById('info_container_bar').style.display = 'none';
  ryi.redraw_editor();
}

ryi.hide_infocontainer = function() {
  document.getElementById('info_container').className = 'hidden';
  setTimeout(ryi.remove_infocontainer,1000);
  createCookie('RYI_SHOW_INFO_TEXT','no',365);
}

ryi.remove_infocontainer = function() {
  document.getElementById('info_container').style.display = 'none';
  document.getElementById('info_container_bar').style.display = 'block';
  ryi.redraw_editor();
}


ryi.show_languageselector = function () {
  document.getElementById('language_selector_dropdown').style.visibility = 'visible';
}

ryi.hide_languageselector = function() {
  document.getElementById('language_selector_dropdown').style.visibility = 'hidden';
}


ryi.toggle_languageselector = function (){

  if (document.getElementById('language_selector_dropdown').style.visibility == 'hidden') {
    ryi.show_languageselector();
  }
  else {
    ryi.hide_languageselector();
  }

}

ryi.select_language = function ( language ) {
	ryi.hide_languageselector();
  var url = igorurl + '/';
  var url = url + language + '/';
  url = url + '?nocache=' + new Date().getTime();
  url = url + window.location.hash;
  document.location.href = url;
}

ryi.init_info = function () {
  if ( readCookie('RYI_SHOW_INFO_TEXT') == 'no' ) {
    ryi.remove_infocontainer();
  } else {
    ryi.create_infocontainer();
  }
}

// ----------------------------------------------------------------------------------------------------
// cookiewarning

ryi.init_cookiewarning = function () {
  if ( readCookie('RYI_HIDE_COOKIEWARNING') != 'yes' ) {
    document.getElementById('cookiewarning').style.display = 'block';
  }
}

ryi.hide_cookiewarning = function () {
  document.getElementById('cookiewarning').style.display = 'none';
  createCookie('RYI_HIDE_COOKIEWARNING','yes',365);
  if ( ryi && ryi.editor ) {
    ryi.redraw_editor()
  }
}

// einde cookiewarning
// ----------------------------------------------------------------------------------------------------
// cookie functies, van https://www.quirksmode.org/js/cookies.html

function createCookie(name,value,days) {
	if (days) {
		var date = new Date();
		date.setTime(date.getTime()+(days*24*60*60*1000));
		var expires = "; expires="+date.toGMTString();
	}
	else var expires = "";
	document.cookie = name+"="+value+expires+"; path=/";
}

function readCookie(name) {
	var nameEQ = name + "=";
	var ca = document.cookie.split(';');
	for(var i=0;i < ca.length;i++) {
		var c = ca[i];
		while (c.charAt(0)==' ') c = c.substring(1,c.length);
		if (c.indexOf(nameEQ) == 0) return c.substring(nameEQ.length,c.length);
	}
	return null;
}

function eraseCookie(name) {
	createCookie(name,"",-1);
}

// einde cookie functies
// ----------------------------------------------------------------------------------------------------
// TAF 

// ------------------------------------------------------------------------------------------------------
// Editor.js
// ------------------------------------------------------------------------------------------------------
// ----------------------------------------------------------------------------------------------------
// editor.js
// ----------------------------------------------------------------------------------------------------
// todo: paramater waarmee je buiten de image kan selecteren
// ----------------------------------------------------------------------------------------------------
// init

ryi.init = function() {

  ryi.borderwidth = 3;
  ryi.zoom_step = .07;

  // todo: dit hoort niet in deze file
  ryi.selection_minimum_width  = 10;
  ryi.selection_minimum_height = 10;

  ryi.editor = document.getElementById('editor');
  ryi.image = document.getElementById('editorimage');

  // selection shortcuts
  ryi.selection_mask    = document.getElementById('selection_mask');

  ryi.selection_nn_mask = document.getElementById('selection_nn_mask');
  ryi.selection_ne_mask = document.getElementById('selection_ne_mask');
  ryi.selection_ee_mask = document.getElementById('selection_ee_mask');
  ryi.selection_se_mask = document.getElementById('selection_se_mask');
  ryi.selection_ss_mask = document.getElementById('selection_ss_mask');
  ryi.selection_sw_mask = document.getElementById('selection_sw_mask');
  ryi.selection_ww_mask = document.getElementById('selection_ww_mask');
  ryi.selection_nw_mask = document.getElementById('selection_nw_mask');

  ryi.arrows_nw = document.getElementById('arrows_nw');
  ryi.arrows_ne = document.getElementById('arrows_ne');
  ryi.arrows_sw = document.getElementById('arrows_sw');
  ryi.arrows_se = document.getElementById('arrows_se');
  ryi.arrows_nn = document.getElementById('arrows_nn');
  ryi.arrows_ss = document.getElementById('arrows_ss');
  ryi.arrows_ee = document.getElementById('arrows_ee');
  ryi.arrows_ww = document.getElementById('arrows_ww');

  // drag and drop dingen
  ryi.selection_mask.init_drag     = ryi.init_drag_selection;
  ryi.selection_mask.do_drag       = ryi.do_drag_selection;
  ryi.selection_mask.end_drag      = ryi.end_drag_selection;
  ryi.selection_nn_mask.init_drag = ryi.selection_ne_mask.init_drag = ryi.selection_ee_mask.init_drag = ryi.selection_se_mask.init_drag = ryi.selection_ss_mask.init_drag = ryi.selection_sw_mask.init_drag = ryi.selection_ww_mask.init_drag = ryi.selection_nw_mask.init_drag = ryi.arrows_nn.init_drag = ryi.arrows_ne.init_drag = ryi.arrows_nw.init_drag = ryi.arrows_ee.init_drag = ryi.arrows_ww.init_drag = ryi.arrows_ss.init_drag = ryi.arrows_se.init_drag = ryi.arrows_sw.init_drag = ryi.init_drag_border;
  ryi.selection_nn_mask.do_drag   = ryi.selection_ne_mask.do_drag   = ryi.selection_ee_mask.do_drag   = ryi.selection_se_mask.do_drag   = ryi.selection_ss_mask.do_drag   = ryi.selection_sw_mask.do_drag   = ryi.selection_ww_mask.do_drag   = ryi.selection_nw_mask.do_drag   = ryi.arrows_nn.do_drag   = ryi.arrows_ne.do_drag   = ryi.arrows_nw.do_drag   = ryi.arrows_ee.do_drag   = ryi.arrows_ww.do_drag   = ryi.arrows_ss.do_drag   = ryi.arrows_se.do_drag   = ryi.arrows_sw.do_drag   = ryi.do_drag_border;
  ryi.selection_nn_mask.end_drag  = ryi.selection_ne_mask.end_drag  = ryi.selection_ee_mask.end_drag  = ryi.selection_se_mask.end_drag  = ryi.selection_ss_mask.end_drag  = ryi.selection_sw_mask.end_drag  = ryi.selection_ww_mask.end_drag  = ryi.selection_nw_mask.end_drag  = ryi.arrows_nn.end_drag  = ryi.arrows_ne.end_drag  = ryi.arrows_nw.end_drag  = ryi.arrows_ee.end_drag  = ryi.arrows_ww.end_drag  = ryi.arrows_ss.end_drag  = ryi.arrows_se.end_drag  = ryi.arrows_sw.end_drag  = ryi.end_drag_border;
  
  // wat maten
  ryi.arrows_90 = {};
  ryi.arrows_90.width  = ryi.arrows_nn.offsetWidth;
  ryi.arrows_90.height = ryi.arrows_nn.offsetHeight;
  ryi.arrows_45 = {};
  ryi.arrows_45.width  = ryi.arrows_ne.offsetWidth;
  ryi.arrows_45.height = ryi.arrows_ne.offsetHeight;

  // event handlers
  ryi.editor.ontouchstart = ryi.handle_touchstart;
  ryi.editor.onmousedown  = ryi.handle_mousedown;

  var only_redraw = ryi.init_datastore();
  ryi.set_new_image( ryi.datastore.filename, only_redraw );

	try {
		if (window.addEventListener) {
			window.addEventListener( 'hashchange', ryi.dohashchange, false );
		} else if (window.attachEvent) {
			window.attachEvent( 'onhashchange', ryi.dohashchange );
		}
	} catch(e) {
	}

  RYI_set_ads();

}

// einde init
// ----------------------------------------------------------------------------------------------------
// change_image

ryi.set_new_image = function( filename, only_redraw ) {

  document.getElementById('pleasewaitcontent').innerHTML = ryi.taal_set['300'];
  ryi.show_pleasewaitlayer();

  ryi.editor.style.opacity = 0;
  ryi.image.style.width  = 'auto';
  ryi.image.style.height = 'auto';
  if ( only_redraw ) {
    ryi.image.onload = ryi.reinit_editor;
  } else {
    ryi.datastore.transform = [];
    ryi.datastore.pages.no_of_pages = 1;
    ryi.datastore.pages.current = 1;
    ryi.datastore.filename = filename;
    ryi.image.onload = ryi.fetch_metadata;
  }

  ryi.image.src = '/images/editor/' + ryi.datastore.filename + '?' + ryi.makeparams('editorimage');

}

ryi.fetch_metadata = function( filename ) {

  var http_request;
	if ( window.XMLHttpRequest ){ 
		http_request = new XMLHttpRequest(); 
	} else if( window.ActiveXObject ){ 
		http_request = new ActiveXObject("Microsoft.XMLHTTP"); 
	} else {
    alert('Your browser does not support AJAX communication. This application will not work correctly without it.');
    return;
  }

  var url = '/metadata/editor/' + ryi.datastore.filename +'?' + ryi.makeparams('editorimage');
	http_request.open( "GET", url, true );
	http_request.send( null );

	http_request.onreadystatechange = function () {
		if ( http_request.readyState == 4 ) {
			if ( http_request.status == 200 ) {
        var result = eval( "(" + http_request.responseText + ")" );
        ryi.datastore.pages.no_of_pages = result.meta_data.pages;
        ryi.init_editor();
        ryi.save_datastore()
      }
    }
  }

}

ryi.change_image = function(src) {

  document.getElementById('pleasewaitcontent').innerHTML = ryi.taal_set['300'];
  ryi.show_pleasewaitlayer();

  ryi.image.onload = ryi.redraw_editor;
  ryi.image.src = src;
  ryi.save_datastore()

}

// einde change_image
// ----------------------------------------------------------------------------------------------------
// init_editor

ryi.init_editor = function( params ) {

  if ( ryi.datastore.pages.no_of_pages > 1 ) {
    ryi.buttons.show_page_selector();
  } else {
    ryi.buttons.hide_page_selector();
  }

  ryi.image.style.width = 'auto'
  ryi.image.style.height = 'auto'

  ryi.unzoomed_width = ryi.image.offsetWidth;
  ryi.unzoomed_height = ryi.image.offsetHeight;

  if ( typeof(params) != 'undefined' && typeof(params.do_not_init_values) != 'undefined' && params.do_not_init_values ) {

    ryi.zoomed_width  = Math.round( ryi.datastore.zoom / 1000 * ryi.unzoomed_width  );
    ryi.zoomed_height = Math.round( ryi.datastore.zoom / 1000 * ryi.unzoomed_height );

  } else {

    // als het image niet past in de beschikbare ruimte zet de initiele zoom op 95% daarvan
    ryi.image.style.display = 'none';
    var space_width  = Math.max( ryi.editor.parentNode.offsetWidth,  200 );
    var space_height = Math.max( ryi.editor.parentNode.offsetHeight, 200 );
    ryi.image.style.display = 'block';

    if ( ryi.datastore.demomode || space_width < ryi.unzoomed_width || space_height < ryi.unzoomed_height ) {
      var zoom_vert = ( space_height ) / ryi.unzoomed_height;
      var zoom_horz = ( space_width )  / ryi.unzoomed_width;
      ryi.datastore.zoom = Math.round( 950 * Math.min( zoom_vert, zoom_horz ) );
    } else {
      ryi.datastore.zoom = 1000;
    }

    ryi.zoomed_width  = Math.round( ryi.datastore.zoom / 1000 * ryi.unzoomed_width  );
    ryi.zoomed_height = Math.round( ryi.datastore.zoom / 1000 * ryi.unzoomed_height );

    // de initiele selectie is 80% van de afbeelding
    ryi.datastore.selection_width  = parseInt( .85 * ryi.zoomed_width  );
    ryi.datastore.selection_height = parseInt( .85 * ryi.zoomed_height );
    ryi.datastore.selection_top    = parseInt( ( ryi.zoomed_height - ryi.datastore.selection_height ) / 2 );
    ryi.datastore.selection_left   = parseInt( ( ryi.zoomed_width  - ryi.datastore.selection_width  ) / 2 );

  }

	// Omdat de timing helemaal hopeloos is.
	// Zet ik hier een global flag om aan te geven dat de editor al init gedaan heeft. 
	// Als dat nog niet is geweest moet je niet een redraw_editor doen..
	ryi.editor_init_done = true;

	try {
		if (window.addEventListener) { // gecko
			window.addEventListener( 'resize', onresize, false );
		} else if (window.attachEvent) { // ie
			window.onresize = onresize;
		}
	} catch(e) {
	}
	

  // er is iets raars met ie8 waardoor hij alleen werkt als hij wat extra tijd krijgt
  setTimeout( function(){
    ryi.redraw_editor();
  }, 100 );

}


ryi.reinit_editor = function() {

  ryi.init_editor({ do_not_init_values:true });

}


// einde init_editor
// ----------------------------------------------------------------------------------------------------
// redraw_editor

ryi.redraw_editor = function() {

	if ( ! ryi.editor_init_done ) {
		setTimeout( function(){
			ryi.redraw_editor();
		}, 200 );
	}
	else {

    var infoHeight = document.getElementById('info_container').offsetHeight;
    infoHeight += document.getElementById('info_container_bar').offsetHeight;
    document.getElementById('content_container').style.bottom = infoHeight + 'px';

    var buttonHeight = document.getElementById('button-bar').offsetHeight;
    document.getElementById('content_container').style.top = buttonHeight + 'px';

		if ( ryi.datastore.pages.no_of_pages > 1 ) {
			ryi.buttons.show_page_selector();
		} else {
			ryi.buttons.hide_page_selector();
		}

		ryi.image.style.width = 'auto'
		ryi.image.style.height = 'auto'

		ryi.unzoomed_width = ryi.image.offsetWidth;
		ryi.unzoomed_height = ryi.image.offsetHeight;

		ryi.zoomed_width  = Math.round( ryi.datastore.zoom / 1000 * ryi.unzoomed_width  );
		ryi.zoomed_height = Math.round( ryi.datastore.zoom / 1000 * ryi.unzoomed_height );

		ryi.image.style.width  = ryi.zoomed_width  + 'px';
		ryi.image.style.height = ryi.zoomed_height + 'px';

		ryi.editor.display = 'none'
		var width  = ryi.zoomed_width;
		var height = ryi.zoomed_height;
		var top   = ( ryi.editor.parentNode.offsetHeight - height ) / 2;
		if ( top < 0 ) {
			top = 0;
		}
		var left   = ( ryi.editor.parentNode.offsetWidth - width ) / 2;
		if ( left < 0 ) {
			left = 0;
		}
		ryi.editor.style.top    = top    + 'px';
		ryi.editor.style.left   = left   + 'px';
		ryi.editor.style.width  = width  + 'px';
		ryi.editor.style.height = height + 'px';

		// nu kunnen er scollbars verdwenen zijn, daarom hetzelfde blok nog eens
		ryi.editor.display = 'none'
		var width  = ryi.zoomed_width;
		var height = ryi.zoomed_height;
		var top   = ( ryi.editor.parentNode.offsetHeight - height ) / 2;
		if ( top < 0 ) {
			top = 0;
		}
		var left   = ( ryi.editor.parentNode.offsetWidth - width ) / 2;
		if ( left < 0 ) {
			left = 0;
		}

		ryi.check_selection();

		ryi.editor.style.top    = top    + 'px';
		ryi.editor.style.left   = left   + 'px';
		ryi.editor.style.width  = width  + 'px';
		ryi.editor.style.height = height + 'px';

		ryi.redraw_selection();
	
		ryi.editor.display = 'block'
		ryi.editor.style.opacity = 1;

		ryi.hide_pleasewaitlayer();

		ryi.ready = true;
	}
}

ryi.redraw_selection = function() {

  var width  = ryi.zoomed_width;
  var height = ryi.zoomed_height;

  
  var widthlijstje = (document.getElementsByClassName('ryi_width_text'));
  for (var plek = 0 ; plek < widthlijstje.length; plek++) {
    widthlijstje[plek].innerHTML = ryi.datastore.selection_width;
  };

//  Array.prototype.forEach.call(document.getElementsByClassName('ryi_width_text'), (element) => {
//    element.innerHTML = ryi.datastore.selection_width;
//  });

  var heightlijstje = (document.getElementsByClassName('ryi_height_text'));
  for (var plek = 0 ; plek < heightlijstje.length; plek++) {
    heightlijstje[plek].innerHTML = ryi.datastore.selection_height;
  };

//  Array.prototype.forEach.call(document.getElementsByClassName('ryi_height_text'), (element) => {
//    element.innerHTML = ryi.datastore.selection_height;
//  });

  ryi.selection_mask.style.top           = ( ryi.datastore.selection_top - ryi.borderwidth ) + 'px';
  ryi.selection_mask.style.left          = ( ryi.datastore.selection_left - ryi.borderwidth ) + 'px';
  ryi.selection_mask.style.width         = ryi.datastore.selection_width + 'px';
  ryi.selection_mask.style.height        = ryi.datastore.selection_height + 'px';

  ryi.selection_nn_mask.style.top        = '0px';
  ryi.selection_nn_mask.style.left       = ryi.datastore.selection_left + 'px';
  ryi.selection_nn_mask.style.width      = ryi.datastore.selection_width + 'px';
  ryi.selection_nn_mask.style.height     = ryi.datastore.selection_top + 'px';

  ryi.selection_ne_mask.style.top        = '0px';
  ryi.selection_ne_mask.style.left       = ( ryi.datastore.selection_left + ryi.datastore.selection_width ) + 'px';
  ryi.selection_ne_mask.style.width      = ( width - ryi.datastore.selection_left - ryi.datastore.selection_width ) + 'px';
  ryi.selection_ne_mask.style.height     = ryi.datastore.selection_top + 'px';

  ryi.selection_ee_mask.style.top        = ryi.datastore.selection_top + 'px';
  ryi.selection_ee_mask.style.left       = ( ryi.datastore.selection_left + ryi.datastore.selection_width ) + 'px';;
  ryi.selection_ee_mask.style.width      = ( width - ( ryi.datastore.selection_left + ryi.datastore.selection_width ) ) + 'px';
  ryi.selection_ee_mask.style.height     = ryi.datastore.selection_height + 'px';

  ryi.selection_se_mask.style.top        = ( ryi.datastore.selection_top + ryi.datastore.selection_height ) + 'px';
  ryi.selection_se_mask.style.left       = ( ryi.datastore.selection_left + ryi.datastore.selection_width ) + 'px';
  ryi.selection_se_mask.style.width      = ( width - ryi.datastore.selection_left - ryi.datastore.selection_width ) + 'px';;
  ryi.selection_se_mask.style.height     = ( height - ryi.datastore.selection_top - ryi.datastore.selection_height ) + 'px';

  ryi.selection_ss_mask.style.top        = ( ryi.datastore.selection_top + ryi.datastore.selection_height ) + 'px';
  ryi.selection_ss_mask.style.left       = ryi.datastore.selection_left + 'px';
  ryi.selection_ss_mask.style.width      = ryi.datastore.selection_width + 'px';
  ryi.selection_ss_mask.style.height     = ( height - ( ryi.datastore.selection_top + ryi.datastore.selection_height ) ) + 'px';

  ryi.selection_sw_mask.style.top        = ( ryi.datastore.selection_top + ryi.datastore.selection_height ) + 'px';
  ryi.selection_sw_mask.style.left       = '0px';
  ryi.selection_sw_mask.style.width      = ryi.datastore.selection_left + 'px';;
  ryi.selection_sw_mask.style.height     = ( height - ryi.datastore.selection_top - ryi.datastore.selection_height ) + 'px';

  ryi.selection_ww_mask.style.top        = ryi.datastore.selection_top + 'px';
  ryi.selection_ww_mask.style.left       = '0px';
  ryi.selection_ww_mask.style.width      = ryi.datastore.selection_left + 'px';
  ryi.selection_ww_mask.style.height     = ryi.datastore.selection_height + 'px';

  ryi.selection_nw_mask.style.top        = '0px';
  ryi.selection_nw_mask.style.left       = '0px';
  ryi.selection_nw_mask.style.width      = ryi.datastore.selection_left + 'px';;
  ryi.selection_nw_mask.style.height     = ryi.datastore.selection_top + 'px';

  // todo: ryi.arrows_n.offsetHeight zit al in ryi.arrows90.width - zie init
  ryi.arrows_nw.style.top                = ( ryi.datastore.selection_top - ryi.arrows_nw.offsetHeight / 2 + 1 )                                          + 'px';
  ryi.arrows_nw.style.left               = ( ryi.datastore.selection_left - ryi.arrows_nw.offsetWidth / 2 )                                              + 'px';

  ryi.arrows_ne.style.top                = ( ryi.datastore.selection_top - ryi.arrows_ne.offsetHeight / 2 + 1 )                                          + 'px';
  ryi.arrows_ne.style.left               = ( ryi.datastore.selection_left + ryi.datastore.selection_width - ryi.arrows_ne.offsetWidth / 2 - 1 )                    + 'px';

  ryi.arrows_se.style.top                = ( ryi.datastore.selection_top + ryi.datastore.selection_height - ryi.arrows_se.offsetHeight / 2 )                       + 'px';
  ryi.arrows_se.style.left               = ( ryi.datastore.selection_left + ryi.datastore.selection_width - ryi.arrows_se.offsetWidth / 2 - 1 )                    + 'px';
  ryi.arrows_sw.style.top                = ( ryi.datastore.selection_top + ryi.datastore.selection_height - ryi.arrows_sw.offsetHeight / 2 )                       + 'px';
  ryi.arrows_sw.style.left               = ( ryi.datastore.selection_left - ryi.arrows_sw.offsetWidth / 2 )                                              + 'px';

  ryi.arrows_nn.style.top                = ( ryi.datastore.selection_top - ( ryi.arrows_nn.offsetHeight + ryi.borderwidth ) / 2 )                        + 'px';
  ryi.arrows_nn.style.left               = ( ryi.datastore.selection_left + ryi.datastore.selection_width / 2 - ryi.arrows_nn.offsetWidth / 2 )                    + 'px';
  ryi.arrows_ss.style.top                = ( ryi.datastore.selection_top + ryi.datastore.selection_height - ( ryi.arrows_nn.offsetHeight - ryi.borderwidth ) / 2 ) + 'px';
  ryi.arrows_ss.style.left               = ( ryi.datastore.selection_left + ryi.datastore.selection_width / 2 - ryi.arrows_ss.offsetWidth / 2 )                    + 'px';
  ryi.arrows_ee.style.top                = ( ryi.datastore.selection_top + ryi.datastore.selection_height / 2 - ( ryi.arrows_ee.offsetHeight ) / 2 )               + 'px';
  ryi.arrows_ee.style.left               = ( ryi.datastore.selection_left + ryi.datastore.selection_width - ( ryi.arrows_ee.offsetWidth - ryi.borderwidth ) / 2 )  + 'px';
  ryi.arrows_ww.style.top                = ( ryi.datastore.selection_top + ryi.datastore.selection_height / 2 - ( ryi.arrows_ww.offsetHeight ) / 2 )               + 'px';
  ryi.arrows_ww.style.left               = ( ryi.datastore.selection_left - ( ryi.arrows_ww.offsetWidth + ryi.borderwidth ) / 2 )                        + 'px';

}

// einde redraw_editor
// ----------------------------------------------------------------------------------------------------
// set_selection_size

ryi.set_selection_width = function( new_selection_width ) {
  if ( ryi.datastore.selection_left + new_selection_width > ryi.zoomed_width  ) {
    new_selection_width = ryi.zoomed_width - ryi.datastore.selection_left;
  }
  ryi.datastore.selection_width = new_selection_width;
  ryi.redraw_selection();
  ryi.save_datastore()
}

ryi.set_selection_height = function( new_selection_height ) {
  if ( ryi.datastore.selection_top + new_selection_height > ryi.zoomed_height  ) {
    new_selection_height = ryi.zoomed_height - ryi.datastore.selection_top;
  }
  ryi.datastore.selection_height = new_selection_height;
  ryi.redraw_selection();
  ryi.save_datastore()
}

// einde set_selection_size
// ----------------------------------------------------------------------------------------------------
// mirror

ryi.mirror_selection = function( which ) {
  if ( which == 'y' ) {
    ryi.datastore.selection_top = ryi.zoomed_height - ryi.datastore.selection_top - ryi.datastore.selection_height;
  }
  if ( which == 'x' ) {
    ryi.datastore.selection_left = ryi.zoomed_width - ryi.datastore.selection_left - ryi.datastore.selection_width;
  }
}

// einde mirror
// ----------------------------------------------------------------------------------------------------
// rotate

ryi.rotate_selection = function( which ) {
  var bak = ryi.datastore.selection_top;
  ryi.datastore.selection_top    = ryi.datastore.selection_left;
  ryi.datastore.selection_left   = ryi.zoomed_height - bak - ryi.datastore.selection_height;
  bak = ryi.datastore.selection_width;
  ryi.datastore.selection_width  = ryi.datastore.selection_height;
  ryi.datastore.selection_height = bak;
}

// einde rotate
// ----------------------------------------------------------------------------------------------------
// zoom

ryi.increase_zoom = function() {
  var new_zoom = parseInt( Math.round( ( ryi.datastore.zoom * ( 1 + ryi.zoom_step ) ) * 1000 ) / 1000 );
  ryi.do_zoom( new_zoom );
}

ryi.decrease_zoom = function() {
  var new_zoom = parseInt( Math.round( ( ryi.datastore.zoom * ( 1 - ryi.zoom_step ) ) * 1000 ) / 1000 );
  ryi.do_zoom( new_zoom );
}

ryi.do_zoom = function( new_zoom ) {

  var new_image_width  = Math.round( ryi.unzoomed_width  * new_zoom / 1000 );
  var new_image_height = Math.round( ryi.unzoomed_height * new_zoom / 1000 );

  var selection_center_top	= Math.round(ryi.datastore.selection_top	+ ryi.datastore.selection_height / 2 );
	var selection_center_left = Math.round(ryi.datastore.selection_left + ryi.datastore.selection_width	 / 2 );

  var new_selection_center_top	= Math.round( selection_center_top  * ( new_image_height / ryi.zoomed_height ) );
	var new_selection_center_left = Math.round( selection_center_left * ( new_image_width  / ryi.zoomed_width  ) );

  var new_selection_top  = Math.round( new_selection_center_top  - ryi.datastore.selection_height / 2 );
  var new_selection_left = Math.round( new_selection_center_left - ryi.datastore.selection_width  / 2 );

  var new_selection_width	 = ryi.datastore.selection_width;
	var new_selection_height = ryi.datastore.selection_height;

  if ( new_selection_top < 0 ) {
    new_selection_top = 0;
    if ( new_selection_height > ryi.zoomed_height )
      new_selection_height = ryi.zoomed_height;
  }

  if ( new_selection_left < 0 ) {
    new_selection_left = 0;
    if ( new_selection_width > ryi.zoomed_width )
      new_selection_width = ryi.zoomed_width;
  }

  if ( new_image_width < new_selection_left + new_selection_width ) {
    new_selection_width = new_image_width - new_selection_left
  }

  if ( new_image_height < new_selection_top + new_selection_height ) {
    new_selection_height = new_image_height - new_selection_top
  }
  
  ryi.datastore.selection_top	   = parseInt(new_selection_top);
	ryi.datastore.selection_left	 = parseInt(new_selection_left);
	ryi.datastore.selection_width  = parseInt(new_selection_width);
	ryi.datastore.selection_height = parseInt(new_selection_height);

  ryi.datastore.zoom = new_zoom;

  ryi.redraw_editor();
  ryi.save_datastore()

}

// einde zoom
// ----------------------------------------------------------------------------------------------------
// check_selection: controleer of de selectie binnen je image valt
// todo: misschien moet dit set_selection(nieuwe waarden) worden, en moet je hem dan gebruiken vanuit alle voorkomende functies

ryi.check_selection = function() {

  // deze wordt soms te vroeg aangeroepenm, vandaar de ready
  if ( ryi.ready ) {

    if ( ryi.datastore.selection_left < 0  ) {
      ryi.datastore.selection_left = 0;
    }

    if ( ryi.datastore.selection_top < 0  ) {
      ryi.datastore.selection_top = 0;
    }

    if ( ryi.datastore.selection_left + ryi.datastore.selection_width > ryi.zoomed_width  ) {
      ryi.datastore.selection_width = parseInt(ryi.zoomed_width - ryi.datastore.selection_left);
    }

    if ( ryi.datastore.selection_top + ryi.datastore.selection_height > ryi.zoomed_height  ) {
      ryi.datastore.selection_height = parseInt(ryi.zoomed_height - ryi.datastore.selection_top);
    }

  }

}

// einde check_selection
// ----------------------------------------------------------------------------------------------------
// drag and drop: algemeen

ryi.init_drag = function( drag_params ) {

  var target;

	if ( drag_params.target.id == 'selection_mask' || drag_params.target.id.search('^selection_[nesw][nesw]?_mask$') != -1 || drag_params.target.id.search('^arrows_[nesw][nesw]?$') != -1 ) {
    target = document.getElementById( drag_params.target.id );
	}

  if ( target && target.init_drag ) {
		ryi.drag_target = target;
		ryi.drag_target.lastX		   = drag_params.clientX;
		ryi.drag_target.lastY		   = drag_params.clientY;
    if ( drag_params.type == 'mouse' ) {
		  document.onmouseup		 = ryi.handle_mouseup;
		  document.onmousemove	 = ryi.handle_mousemove;
    } else {
		  document.ontouchend		 = ryi.handle_touchend;
		  document.ontouchmove	 = ryi.handle_touchmove;
		  document.ontouchcancel = ryi.handle_touchcancel;
    }
    target.init_drag();
  }

	// safari wil blijkbaar een true hebben voordat hij de click wil verder verwerken.
	return false;
  
}

ryi.end_drag = function() {

  drag_extrafunction = null;

  document.onmousemove = null;
  document.onmouseup   = null;
	document.ontouchend		 = null;
	document.ontouchmove	 = null;
	document.ontouchcancel = null;

  if ( ryi.drag_target.end_drag ) {
    eval("ryi.drag_target.end_drag()");
  }

  ryi.drag_target = null;

  return false;
  
}

// einde drag and drop: algemeen
// --------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
// drag and drop: selection

ryi.init_drag_selection = function() {

  // waarden
  ryi.last_selection_top	  = ryi.ryi.datastore.selection_width  = new_selection_width;
	ryi.datastore.selection_height = new_selection_height;

  ryi.datastore.zoom = new_zoom;

  ryi.redraw_editor();

}

// einde zoom
// --------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
// drag and drop: selection

ryi.init_drag_selection = function() {

  // waarden
  ryi.last_selection_top	  = ryi.datastore.selection_top;
	ryi.last_selection_left   =	ryi.datastore.selection_left ;
  ryi.last_selection_width	= ryi.datastore.selection_width;
	ryi.last_selection_height =	ryi.datastore.selection_height;

  // cursor
  document.body.style.cursor = 'move';

}

ryi.do_drag_selection = function( drag_params ) {

  var target = drag_params.target;

  new_selection_top  = ryi.last_selection_top  + ( drag_params.clientY - ryi.drag_target.lastY  );
  new_selection_left = ryi.last_selection_left + ( drag_params.clientX - ryi.drag_target.lastX );
  
  if ( new_selection_top < 0 ) {
    new_selection_top = 0;
  }
  if ( new_selection_top + ryi.datastore.selection_height > ryi.zoomed_height ) {
    new_selection_top  = ryi.zoomed_height - ryi.datastore.selection_height;
  }
  if ( new_selection_left < 0 ) {
    new_selection_left = 0;
  }
  if ( new_selection_left + ryi.datastore.selection_width > ryi.zoomed_width ) {
    new_selection_left  = ryi.zoomed_width - ryi.datastore.selection_width;
  }

  ryi.datastore.selection_top  = new_selection_top;
  ryi.datastore.selection_left = new_selection_left;

  ryi.redraw_selection();

  return false;
  
}

ryi.end_drag_selection = function() {
  ryi.save_datastore()
  // cursor terug naar normaal
  document.body.style.cursor = 'default';
}

// einde drag and drop: selection
// --------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
// drag and drop: borders

ryi.init_drag_border = function() {

  // waarden
  ryi.last_selection_top	  = ryi.datastore.selection_top;
	ryi.last_selection_left   =	ryi.datastore.selection_left ;
  ryi.last_selection_width	= ryi.datastore.selection_width;
	ryi.last_selection_height =	ryi.datastore.selection_height;

  // mousepointer
	var direction = ryi.drag_target.id.replace(/^(?:selection_|arrows_)([nesw][nesw])(?:_mask|$)/, '$1');
  direction = direction.replace( /([nesw])\1/, '$1' );
  document.body.style.cursor = direction + '-resize';
  
}

ryi.do_drag_border = function(drag_params) {

  var diff_x = ( drag_params.clientX - ryi.drag_target.lastX );
  var diff_y = ( drag_params.clientY - ryi.drag_target.lastY );

  var new_selection_top    = ryi.last_selection_top;
  var new_selection_left   = ryi.last_selection_left;
  var new_selection_width  = ryi.last_selection_width;
  var new_selection_height = ryi.last_selection_height;

  var which_border_is_dragged = ryi.drag_target.id.replace( /_mask$/, '' );
  which_border_is_dragged = which_border_is_dragged.replace( /^.*_([nesw][nesw])$/, '$1' );

  if (which_border_is_dragged == 'nn' || which_border_is_dragged == 'ne' || which_border_is_dragged == 'nw' ) {
    var new_selection_top = ryi.last_selection_top + diff_y;
    var new_selection_height = ryi.last_selection_height - diff_y;
  }
  if (which_border_is_dragged == 'ee' || which_border_is_dragged == 'ne' || which_border_is_dragged == 'se' ) {
    var new_selection_width = ryi.last_selection_width + diff_x;
  }
  if (which_border_is_dragged == 'ss' || which_border_is_dragged == 'se' || which_border_is_dragged == 'sw' ) {
    var new_selection_height = ryi.last_selection_height + diff_y;
  }
  if (which_border_is_dragged == 'ww' || which_border_is_dragged == 'nw' || which_border_is_dragged == 'sw' ) {
    var new_selection_left = ryi.last_selection_left + diff_x;
    var new_selection_width = ryi.last_selection_width - diff_x;
  }

  if ( new_selection_top < 0 ) {
    new_selection_top = 0;
    diff_y = - ryi.last_selection_top;
    new_selection_height = ryi.last_selection_height - diff_y;
  }
  if ( new_selection_left < 0 ) {
    new_selection_left = 0;
    diff_x = - ryi.last_selection_left;
    new_selection_width = ryi.last_selection_width - diff_x;
  }

  if ( new_selection_left + new_selection_width > ryi.zoomed_width  ) {
    new_selection_width = ryi.zoomed_width - new_selection_left;
  }
  if ( new_selection_top + new_selection_height > ryi.zoomed_height  ) {
    new_selection_height = ryi.zoomed_height - new_selection_top;
  }

  if ( new_selection_width < ryi.selection_minimum_width  ) {
    new_selection_width = ryi.selection_minimum_width;
  }
  if ( new_selection_height < ryi.selection_minimum_height  ) {
    new_selection_height = ryi.selection_minimum_height;
  }

  if ( new_selection_height == ryi.selection_minimum_height && which_border_is_dragged == 'nn' || which_border_is_dragged == 'ne' || which_border_is_dragged == 'nw' ) {
    var bottom = ryi.last_selection_top + ryi.last_selection_height;
    new_selection_top = bottom - new_selection_height;
  }

  if ( new_selection_width == ryi.selection_minimum_width && which_border_is_dragged == 'ww' || which_border_is_dragged == 'nw' || which_border_is_dragged == 'sw' ) {
    var right = ryi.last_selection_left + ryi.last_selection_width;
    new_selection_left = right - new_selection_width;
  }

  ryi.datastore.selection_top    = parseInt(new_selection_top);
  ryi.datastore.selection_left   = parseInt(new_selection_left);
  ryi.datastore.selection_width  = parseInt(new_selection_width);
  ryi.datastore.selection_height = parseInt(new_selection_height);

  ryi.redraw_selection();
  
  return false;
  
}

ryi.end_drag_border = function() {
  ryi.save_datastore()
  // cursor terug naar normaal
  document.body.style.cursor = 'default';
}

// einde drag and drop: borders
// --------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
// mouse events

ryi.input_event_class = function() {
  ryi.input_event_class.type = 'mouse';
	ryi.input_event_class.target = {};
	ryi.input_event_class.clientX = new Number;
	ryi.input_event_class.clientY = new Number;
}
	

ryi.handle_mousedown = function(event) {

  event = (event) ? event : window.event;
  var target = event.target || event.srcElement;

  var input_event = new ryi.input_event_class;
  input_event.type = 'mouse';
	input_event.target = target;
	input_event.clientX = event.clientX;
	input_event.clientY = event.clientY;

  ryi.init_drag( input_event );

	return false;
}

ryi.handle_mousemove = function(event) {

  event = (event) ? event : window.event;
  var target = event.target || event.srcElement;

  var input_event = new ryi.input_event_class;
  input_event.type = 'mouse';
	input_event.target = target;
	input_event.clientX = event.clientX;
	input_event.clientY = event.clientY;

  ryi.drag_target.do_drag( input_event );

	return false;

}

ryi.handle_mouseup = function(event) {

  event = (event) ? event : window.event;
  var target = event.target || event.srcElement;

  var input_event = new ryi.input_event_class;
  input_event.type = 'mouse';
	input_event.target = target;
	input_event.clientX = event.clientX;
	input_event.clientY = event.clientY;

  ryi.end_drag( input_event );
  
	return false;

}

// einde mouse events
// --------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
// touch events

ryi.handle_touchstart = function(event) {

	// wat is mijn target
  var target = event.target || event.srcElement;

	// get the total number of fingers touching the screen
	var fingerCount = event.touches.length;
	// since we're looking for a swipe (single finger) and not a gesture (multiple fingers),
	// check that only one finger was used
	if ( fingerCount == 1 ) {
		// get the coordinates of the touch

    if ( event.target.id.search('^selection_[nesw][nesw]?_mask$') != -1 && document.getElementById('ad_bottom').offsetHeight > 0 ) { // als mobile dan is de grijze omgeving, om te scrollen
      // TODO: de afvanging klopt, maar scrollen doet hij niet
      return true;
    }

		var input_event = new ryi.input_event_class;
		input_event.type = 'touch';
		input_event.target = target;
		input_event.clientX = event.touches[0].pageX;
		input_event.clientY = event.touches[0].pageY;

	  event.preventDefault(); // disable the standard ability to select the touched object
		ryi.init_drag(input_event);
	} 
	else {
		// more than one finger touched so cancel
	  event.preventDefault(); // disable the standard ability to select the touched object
		handle_touchcancel(event);
	}

}

ryi.handle_touchmove = function(event) {

	// disable the standard ability to select the touched object
	event.preventDefault();

  // wat is mijn target
  var target = event.target || event.srcElement;

	// get the total number of fingers touching the screen
	var fingerCount = event.touches.length;
	// since we're looking for a swipe (single finger) and not a gesture (multiple fingers),
	// check that only one finger was used
	if ( fingerCount == 1 ) {
		// get the coordinates of the touch
		var input_event = new ryi.input_event_class;
		input_event.type = 'touch';
		input_event.target = target;
		input_event.clientX = event.touches[0].pageX;
		input_event.clientY = event.touches[0].pageY;

	  ryi.drag_target.do_drag( input_event );

	} 
	else {
		handle_touchcancel(event);
	}

}

ryi.handle_touchcancel = function(event) {

	// disable the standard ability to select the touched object
	event.preventDefault();

	ryi.end_drag();

}

ryi.handle_touchend = function(event) {

	// disable the standard ability to select the touched object
	event.preventDefault();

	ryi.end_drag();

}

// einde touch events
// ----------------------------------------------------------------------------------------------------
// data store

ryi.init_datastore = function() {

  // lees de eventueel meegstuurde data
  var data = window.location.hash;
  data = data.substring(1);
  var pairs = data.split('&');
  data = {};
  for ( var i=0; i<pairs.length; i++ ) {
    var pair = pairs[i].split('=');
    if ( data[ pair[0] ] ) {
      if ( !Array.isArray( data[ pair[0] ] ) ) {
        data[ pair[0] ] = [ data[ pair[0] ] ];
      }
      data[ pair[0] ].push( pair[1] );
    } else {
      data[ pair[0] ] = pair[1];
    }
  }

  // en maak dan de datastore, waar nodig met die meegestuurde data
  ryi.datastore = {};
  ryi.datastore.filename = typeof(data.filename) != 'undefined' ? data.filename : Math.floor( 4 * Math.random() ) + '.jpg';
  ryi.datastore.selection_top    = typeof(data.selection_top) != 'undefined' ? parseInt( data.selection_top ) : 0;
  ryi.datastore.selection_left   = typeof(data.selection_left) != 'undefined' ? parseInt( data.selection_left ) : 0;
  ryi.datastore.selection_width  = typeof(data.selection_width) != 'undefined' ? parseInt( data.selection_width ) : 0;
  ryi.datastore.selection_height = typeof(data.selection_height) != 'undefined' ? parseInt( data.selection_height ) : 0;
  ryi.datastore.zoom = typeof(data.zoom) != 'undefined' ? parseInt( data.zoom ) : 1000;
  ryi.datastore.demomode = typeof(data.demomode) != 'undefined' ? data.demomode : true;
  // ryi.datastore.language_id = typeof(data.language_id) != 'undefined' ? parseInt( data.language_id ) : 0; // todo:deze kan nog defaulten naar de taal van je browser

  // transform is altijd een array
  if ( typeof(data.transform) != 'undefined' ) {
    if ( !Array.isArray( data.transform ) ) {
      data.transform = [ data.transform ];
    }
	  ryi.datastore.transform = data.transform;
  } else {
    ryi.datastore.transform = [];
  }

  // pages is een hash met twee keys
	// ryi.datastore.pages = ryi.datastore.pages || {};
  ryi.datastore.pages = {};
	ryi.datastore.pages.no_of_pages = typeof(data.no_of_pages) != 'undefined' ? parseInt( data.no_of_pages ) : 1;
	ryi.datastore.pages.current = typeof(data.page_no) != 'undefined' ? parseInt( data.page_no ) : 1;

  return typeof(data.filename) != 'undefined';

}

ryi.save_datastore = function() {
  var params = ryi.makeparams('editor');
  window.location.hash = params;
  ryi.datastore_just_saved = true;
}

ryi.makeparams = function( which ) {

  var params = [];

  var transforms = simplify_transformations( ryi.datastore.transform );

  for ( var i in transforms ) {
    params.push( 'transform=' + transforms[i] );
  }
  params.push( 'page_no=' + ryi.datastore.pages.current );
  params.push( 'no_of_pages=' + ryi.datastore.pages.no_of_pages );
  
  if ( which == 'editor' || which == 'result' ) {
    params.push( 'filename=' + ryi.datastore.filename );
    params.push( 'selection_top='    + ryi.datastore.selection_top    );
    params.push( 'selection_left='   + ryi.datastore.selection_left   );
    params.push( 'selection_width='  + ryi.datastore.selection_width  );
    params.push( 'selection_height=' + ryi.datastore.selection_height );
    params.push( 'zoom=' + ryi.datastore.zoom );
  }
    
  if ( which == 'result' ) {
    params.push( 'get_as_imagetype=' + 'jpg' );
    params.push( 'do_resize=true' );
  }

  params.push( 'demomode=' + ryi.datastore.demomode );

  if ( which == 'result' ) {
    params.push( 'nocache=' + new Date().getTime() );
  }

  return params.join('&');

}

function simplify_transformations( transforms ) {

  // ik heb iets dat met strings werkt, maar de transforms zijn een array; dat moet
  // dus nog versimpeld zodat ze beide hetzelfde gebruiken
  var string = '';
  for ( var i=0; i<transforms.length; i++ ) {
    string = string + transforms[i].replace( 'transform=', '' ) + ' ';
  }

  var combies = { 'mx my'  : 'r180',
                  'my mx'  : 'r180',
                  'mx mx'  : '',
                  'my my'  : '',

                  'r90 my' : 'mx r90',
                  'r180 my': 'mx',
                  'r270 my': 'mx r270',

                  'r90 mx' : 'mx r270',
                  'r180 mx': 'my',
                  'r270 mx': 'mx r90' };

  string = simplify_rotations( string );
  var REresult = /(?: m[xy] )|(?:r[0-9]{2,3})? m[xy]/.exec( string );
  while ( REresult ) {
    var keys = [];
    for ( var propertyName in combies ) {
      keys.push(propertyName);
    }
    for  ( var i in keys ) {
      var key = keys[i];
      string = string.replace(  key, combies[ key ] );
    }
    string = simplify_rotations( string );
    REresult = /(?: m[xy] )|(?:r[0-9]{2,3})? m[xy]/.exec( string );
  }

  string = string.replace( /  +/, ' ' ); string = string.replace( /^ +/, '' ); string = string.replace( / +$/, '' ); // trim
  return string.split(' ');

  function simplify_rotations( string ) {

    var REresult = /r([0-9]{2,3}) r([0-9]{2,3})/.exec( string );
    while ( REresult && REresult.length > 2 ) {
      var opgeteld = parseInt( REresult[1] ) + parseInt( REresult[2] );

      opgeteld = opgeteld % 360;
      string = string.replace( "r" + REresult[1] + " r" + REresult[2], "r" + opgeteld );
      string = string.replace( "r0", '' );
      string = string.replace( / +/, ' ' );
      REresult = /r([0-9]{2,3}) r([0-9]{2,3})/.exec( string );
      
    }

    string = string.replace( /  +/, ' ' ); string = string.replace( /^ +/, '' ); string = string.replace( / +$/, '' ); // trim
    return string;

  }

}

// isArray bestaat niet in alle browsers
if (!Array.isArray) {
  Array.isArray = function(arg) {
    return Object.prototype.toString.call(arg) === '[object Array]';
  };
}

// einde data store
// ----------------------------------------------------------------------------------------------------
// onhashchange

ryi.dohashchange = function() {
  if ( !ryi.datastore_just_saved ) {
    ryi.init_datastore();
    ryi.set_new_image( ryi.datastore.filename, true );
  }
  ryi.datastore_just_saved = false;
}


// einde onhashchange
// ----------------------------------------------------------------------------------------------------
// TAF


// ------------------------------------------------------------------------------------------------------
// Editor buttons.js
// ------------------------------------------------------------------------------------------------------

// ----------------------------------------------------------------------------------------------------
// upload

ryi.buttons.show_progress_bar = function(tempfile_id) {
  ryi.buttons.progressaantal = 0;
  ryi.buttons.progresstimer = setInterval( 'ryi.buttons.update_progress_bar('+tempfile_id+')', 1000 );
  document.getElementById('pleasewaitcontent').innerHTML = ryi.taal_set['304'] + ': 0% ' + ryi.taal_set['305'];
}

ryi.buttons.update_progress_bar = function(tempfile_id) {

  // we gaan hier niet eeuwig mee door
  ryi.buttons.progressaantal++;
  if ( ryi.buttons.progressaantal > 1000 ) {
    clearInterval(ryi.buttons.progresstimer)
  }

  var http_request;
	if ( window.XMLHttpRequest ){ 
		http_request = new XMLHttpRequest(); 
	} else if( window.ActiveXObject ){ 
		http_request = new ActiveXObject("Microsoft.XMLHTTP"); 
	} else {
    alert('Your browser does not support AJAX communication. This application will not work correctly without it.');
    return;
  }

  var url = '/progress/?tempfile_id=' + tempfile_id + '&nocache=' + new Date().getTime();
	http_request.open( "GET", url, true );
	http_request.send( null );

	http_request.onreadystatechange = function () {
		if ( http_request.readyState == 4 ) {
			if ( http_request.status == 200 ) {
        document.getElementById('pleasewaitcontent').innerHTML = ryi.taal_set['304'] + ': ' + http_request.responseText + '% ' + ryi.taal_set['305'];
      }
    }
  }
  
}

ryi.buttons.upload_finished = function( filename, imagetype ) {

  if ( ryi.datastore ) {
    ryi.datastore.demomode = 0;
  }
  ryi.set_new_image( filename )
  
  clearInterval(ryi.buttons.progresstimer)

}

// einde upload
// ----------------------------------------------------------------------------------------------------
// set_selection_size

ryi.buttons.set_selection_width = function() {
	var new_width = prompt(ryi.taal_set['301'],ryi.datastore.selection_width);
  if ( new_width ) {
    if ( new_width.search(/^\d+$/) != -1 ) {
      new_width = parseInt(new_width);
      var widthlijstje = (document.getElementsByClassName('ryi_width_text'));
      for (var plek = 0 ; plek < widthlijstje.length; plek++) {
        widthlijstje[plek].innerHTML = ryi.datastore.selection_width;
      };

//      Array.prototype.forEach.call(document.getElementsByClassName('ryi_width_text'), (element) => {
//       element.innerHTML = ryi.datastore.selection_width;
//      });

      ryi.set_selection_width( new_width );
    } else {
      alert(ryi.taal_set['303'])
    }
  }
}

ryi.buttons.set_selection_height = function() {
	var new_height = prompt(ryi.taal_set['302'],ryi.datastore.selection_height);
  if ( new_height ) {
    if ( new_height.search(/^\d+$/) != -1 ) {
      new_height = parseInt(new_height);
      var heightlijstje = (document.getElementsByClassName('ryi_height_text'));
      for (var plek = 0 ; plek < heightlijstje.length; plek++) {
        heightlijstje[plek].innerHTML = ryi.datastore.selection_height;
      };

      //Array.prototype.forEach.call(document.getElementsByClassName('ryi_height_text'), (element) => {
      //  element.innerHTML = ryi.datastore.selection_height;
      //});
      ryi.set_selection_height( new_height );
    } else {
      alert(ryi.taal_set['303'])
    }
  }
}

// einde set_selection_size
// ----------------------------------------------------------------------------------------------------
// mirror

ryi.buttons.do_mirror = function( which ) {

  document.getElementById('pleasewaitcontent').innerHTML = ryi.taal_set['300'];
  ryi.show_pleasewaitlayer();

  ryi.datastore.transform.push('transform=m'+which);

  ryi.mirror_selection( which );
  
  ryi.change_image( '/images/editor/' + ryi.datastore.filename + '?' + ryi.makeparams('editorimage') );

}

// einde mirror
// ----------------------------------------------------------------------------------------------------
// rotate

ryi.buttons.do_rotate = function() {

  document.getElementById('pleasewaitcontent').innerHTML = ryi.taal_set['300'];
  ryi.show_pleasewaitlayer();

  ryi.datastore.transform.push('transform=r90');

  var tmp = ryi.unzoomed_height;
  ryi.unzoomed_height = ryi.unzoomed_width;
  ryi.unzoomed_width  = tmp;

  ryi.rotate_selection();

  ryi.change_image( '/images/editor/' + ryi.datastore.filename + '?' + ryi.makeparams('editorimage') );

}

// einde rotate
// ----------------------------------------------------------------------------------------------------
// zoom

ryi.buttons.increase_zoom = function() {
  ryi.increase_zoom()
}

ryi.buttons.decrease_zoom = function() {
  ryi.decrease_zoom()
}

// einde zoom
// ----------------------------------------------------------------------------------------------------
// resize

ryi.buttons.do_resize = function() {
  ryi.save_datastore();
  document.getElementById('pleasewaitcontent').innerHTML = ryi.taal_set['300'];
  ryi.show_pleasewaitlayer();
  document.location.href = '?' + ryi.makeparams('result');
}

// einde resize
// ----------------------------------------------------------------------------------------------------
// interne functies


// einde interne functies
// ----------------------------------------------------------------------------------------------------
// paginering

ryi.buttons.show_page_selector = function() {

  var innerhtml = '';

  innerhtml = innerhtml + ryi.taal_set['800'] +' ' + ryi.taal_set['801'] + ': ';
  
  
  if ( ryi.datastore.pages.current > 1 ) {
    innerhtml = innerhtml + '<a href="javascript: void ryi.buttons.goto_page(' + ( ryi.datastore.pages.current - 1 ) + ')">&lt;&lt;</a>&nbsp;&nbsp;'
  }

  var start = Math.max( ryi.datastore.pages.current - 3, 1 );
  var einde = Math.min( ryi.datastore.pages.current + 4, ryi.datastore.pages.no_of_pages + 1 );

  for ( var i=start; i<einde; i++ ) {
    if ( i == ryi.datastore.pages.current ) {
      innerhtml = innerhtml + '<strong>'+i+'</strong>' + '&nbsp;&nbsp;';
    } else {
      innerhtml = innerhtml + '<a href="javascript: void ryi.buttons.goto_page(' + i + ')">' + i + '</a>&nbsp;&nbsp;';
    }
  }

  if ( ryi.datastore.pages.current < ryi.datastore.pages.no_of_pages ) {
    innerhtml = innerhtml + '<a href="javascript: void ryi.buttons.goto_page(' + ( ryi.datastore.pages.current + 1 ) + ')">&gt;&gt;</a>'
  }

  document.getElementById('page_selector').innerHTML = innerhtml;
  document.getElementById('page_selector').style.display = 'block';

}

ryi.buttons.hide_page_selector = function() {
  document.getElementById('page_selector').style.display = 'none';
}

ryi.buttons.goto_page = function( page_nr ) {
  document.getElementById('pleasewaitcontent').innerHTML =  ryi.taal_set['300'];
  ryi.show_pleasewaitlayer();
  ryi.datastore.pages.current = page_nr;
  ryi.change_image( '/images/editor/' + ryi.datastore.filename + '?' + ryi.makeparams('editorimage') );
  ryi.buttons.show_page_selector();
}

// einde paginering
// ----------------------------------------------------------------------------------------------------
// google ads

function RYI_set_ads() {

   (adsbygoogle = window.adsbygoogle || []).push({});
   (adsbygoogle = window.adsbygoogle || []).push({});
   (adsbygoogle = window.adsbygoogle || []).push({});


  // ondervangen add blockers
  // nu met een timeout om het async loaden van de scripts te ondervangen
  setTimeout( function(){
		if( typeof(window.google_onload_fired) == 'undefined' ) {
			document.getElementById('ad-right').innerHTML = '<div style="padding: 5px; color: white;;">Please consider unblocking our ads to help support further development. Thanks!</div>';
			document.getElementById('ad-left').innerHTML = '<div style="padding: 5px; color: white;">Please consider unblocking our ads to help support further development. Thanks!</div>';
			document.getElementById('ad-bottom').innerHTML = '<div style="padding: 5px; color: white;">Please consider unblocking our ads to help support further development. Thanks!</div>';
		}

	}, 10000 );

}

// einde google ads
// ----------------------------------------------------------------------------------------------------
// TAF


// ------------------------------------------------------------------------------------------------------
// Result.js
// ------------------------------------------------------------------------------------------------------
// in IE < =8 vragen we gewoon het image op
// Want die kan geen data uri of geen data uri groter dan 32k aan.
// 
// 
//
// ben ik die ie dan fallback = 1 zetten


var fallback =0;
var http_request;

function RYI_get_result() {

	document.getElementById('pleasewaitcontent').innerHTML = ryi.taal_set['300'];
	ryi.show_pleasewaitlayer();

	result_image.fullimgurl = result_image.result_image_url + '.' + result_image.get_as_imagetype + '?' + result_image.result_image_querystring + '&get_as_imagetype='+ result_image.get_as_imagetype +'&quality='+result_image.quality;
	
	if ( window.XMLHttpRequest ){ 
		http_request = new XMLHttpRequest(); 
	} else if( window.ActiveXObject ){ 
		http_request = new ActiveXObject("Microsoft.XMLHTTP");
	}	 
	else {
		//alert(navigator.appName);
		fallback =1 ;
	}
	
	if (!fallback) {
		var url = result_image.fullimgurl + '&include_filesize=1&as_html=1';
		http_request.open( "GET", url, true );
		http_request.send( null );
		http_request.onreadystatechange = function () {
			if ( http_request.readyState == 4 ) {
				if ( http_request.status == 200 ) {
					document.getElementById('result').innerHTML = http_request.responseText;
          var classname = document.getElementById('save_result_button').className;
          classname = classname.replace(/ inactive/, '');
					document.getElementById('save_result_button').className = classname;
					ryi.hide_pleasewaitlayer();
				}
			}
		}
	}

	if (fallback) {
		document.getElementById('result').innerHTML = '<img id="result_image" src="'+result_image.fullimgurl+'"><br/>';
		ryi.hide_pleasewaitlayer();
	}

	// document.getElementById('techniek_show_url').innerHTML = result_image.fullimgurl;

}
	


function RYI_set_type_to(image_format)	{
	result_image.get_as_imagetype=image_format;
	RYI_get_result();
}

function RYI_set_higher_quality()	 {
	result_image.quality = parseInt(result_image.quality) +5;
	if (	 result_image.quality > 100 ) {
			result_image.quality =100;
	}
	RYI_get_result();
}

function RYI_set_lower_quality()	{
	result_image.quality = parseInt(result_image.quality) -5;
	if (	 result_image.quality < 5 ) {
			result_image.quality =5;
	}
	RYI_get_result();
}


function RYI_save()	 {
  if ( result_image.fullimgurl ) {
	  var download_url = result_image.fullimgurl + '&download=y';
	  //alert(download_url);
	  document.location = download_url;
  }
}	

