

var tl = new TimelineMax({repeat:0, repeatDelay:2.8});


window.onload = function() {   
    
	tl.set(banner, {visibility: "visible"})

	/*frame one*/	
	.add("frame1")
	.from(".frame-1-text, .frame-1-text-1, .frame-1-text-2, .dell-logo, .vendor-logo, .product1", .5, {alpha:0, ease:Linear.easeIn}, "frame1")
	.to(".frame-1-text, .frame-1-text-1", .5, {alpha:0, ease:Power4.easeOut}, "frame1+=3.7")


	/*frame two*/
	.add("frame2","frame1+=3.9")
    .from(".frame-2-text", .5, {alpha:0, ease:Linear.easeIn}, "frame2")
	.to(".frame-2-text", .5, {alpha:0, ease:Power4.easeOut}, "frame2+=3.7")

	/*frame three*/
	.add("frame3","frame2+=3.9")
	.from(".frame-3-text", .5, {alpha:0, ease:Linear.easeIn}, "frame3")
	.to(".frame-3-text", .5, {alpha:0, ease:Power4.easeOut}, "frame3+=3.7")

	/*frame four*/
	.add("frame4","frame3+=3.9")
	.from(".cta,.frame-4-text", .5, {alpha:0, ease:Linear.easeIn}, "frame4")
	

		 
    ;
  // tl.seek("loop")

  var currentDuration = tl.duration();
  console.log(currentDuration);  

  };