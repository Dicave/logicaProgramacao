<!DOCTYPE html>
<html>
<head>

	<title>Cadastro Jurídico</title>
	<meta charset="utf-8">
	<link rel="stylesheet" type="text/css" href="cadastro_juridico.css">

</head>

<body>

	<header id="cabeçalho">

		<p>Worker Market</p>
		
		<img src="img/mockup1.jpg">

	</header>

<form action="cadastro_juridico_pdo.php" method="POST">

	<div id="nome">
		
		<h1>Nome Da Empresa</h1>
		<p><input type="name" placeholder="NOME" name="nome"></p>

	</div>

	<div id="endereço">
		
		<h1>Endereço</h1>
		<p><input type="name" placeholder="ENDEREÇO" name="endereco"></p>

	</div>

	<div id="data_cnpj">

		<h1>Data De Fundação</h1>

	<div id="date">

		<p><input type="date" name="data"></p>

	</div>

	<div id="cnpj">

		<p><input type="text" placeholder="NÚMERO DO CNPJ" name="cnpj"></p>

	</div>

	</div>

	<div id="conta">
		
	<h1>Conta</h1>

		<div id="conta_email">
			<p><input type="email" placeholder="E-MAIL" name="email"></p>
		</div>

		<div id="conta_senha">
			<p><input type="password" placeholder="SENHA" name="senha"/></p>
		</div>	

	</div>
	
	<div id="img-pessoas">

		<img src="img/mockup.png">

	</div>

	<div id="frase">
		
		<p><b>Seu futuro é conosco!</b></p>

	</div>

	<div id="finalizar">
		
		<input type="submit" name="submit" value="FINALIZAR"/>

	</div>

</form>

	<div id="footer">
		
		<footer>Copyright @ 2019 Worker Market Inc.</footer>

	</div>

</body>
</html>