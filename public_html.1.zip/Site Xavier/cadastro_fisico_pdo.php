<?php


//Conexão com o banco de dados hfs
$dbhost = 'localhost';
$dbuser = 'aluno';
$dbpassword = 'aluno';
$dbbase = 'cadastro_fisico';
$conexao = mysql_connect($server, $user, $password) or die ("Erro de conexão com o banco");
mysql_select_db($base);


//Obtém os valores do formulário
$nome = $_POST['nome'];
$sobrenome = $_POST['sobrenome'];
$nascimento = $_POST['nascimento'];
$cpf = $_POST['cpf'];
$email = $_POST['email'];
$senha = $_POST['senha'];

//criar o query
$query = "INSERT INTO usuario (nome, sobrenome, nascimento, cpf, email, senha) VALUES('$nome', '$sobrenome', '$nascimento', '$cpf', '$email', '$senha')";

$result = mysqli_query($link, $query)or die ('Error queryng database.');

mysqli_close ($link);
header("cadastro_fisico.html");

?>
