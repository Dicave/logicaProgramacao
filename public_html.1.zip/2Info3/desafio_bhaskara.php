<?php 

print "Digite o valor a:";
$a = fgets(STDIN);

print "Digite o valor b:";
$b = fgets(STDIN);

print "Digite o valor c:";
$c = fgets(STDIN);

$delta = pow($b, 2) -4 * $a * $c;

$x1 = (-$b - sqrt($delta)) / (2*$a);
$x2 = (-$b + sqrt($delta)) / (2*$a);

print "Delta = $delta \n";
print "x1 = $x1 \n";
print "x2 = $x2";