<?php

print "Escreva quantos metros você quer converter para centímetro:";
$metros = fgets(STDIN);

$centimetros = $metros*100;

print "$metros metros são $centimetros centímetros ";
