<?php 
    //$booleana = 16 > 18;

    // a função var_dump exibe detalhes de uma variável

    //var_dump($booleana);

    //print PHP_INT_MAX;

    $nome = "Araquari";
//Aspas simples = texto literal
// Aspas duplas = interpolar
    print $nome[0];
    print $nome[1];

