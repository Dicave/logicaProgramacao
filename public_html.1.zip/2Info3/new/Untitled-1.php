from random import randlint

print ('Joga os dados')

dado1 = randlint (1,6)
