<?php
  //O que acontece ao se executar o algoritimo abaixo
  $contador = 0;
    
    while($contador < 3){
        print$contador;
        $contador +=1; #soma mais um a variável   

    } 
    print "Saiu da Repetição";