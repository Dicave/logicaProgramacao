<!DOCTYPE html>
<html>
<head>
<meta charset="utf-8">
<title>Formulário de Contato</title>
<link rel="stylesheet" href="class.css">
</head>
<body>
<br>
<p class="titulos">Formulário de Contato</p>
<?php
include("email_form.php")
?>
<br>
<div class="home_link">
<a href="../">Home</a>
</div>
</body>
</html>