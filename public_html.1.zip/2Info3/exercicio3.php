<?php
//Escreva um programa ler 2 números (A e B) e trocar os seus valores. Apresente os valores de A e B após a troca e aplique o teste de mesa.//

$a = 333;

$b = 8;

//Troca//

$temporaria = $a;
$a = $b;
$b = $temporaria;

// \$a para não interpretar o valor.//
print "O valor de \$a é $a e $b";