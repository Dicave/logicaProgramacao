<?php

//Exercício de imprimir somente números ímpares entre 1-50//
$contador=0;
$valor=0;

while ($contador<50){

    $contador++;
    $valor++;

    if($valor %2 <>0){
        print "O número $valor é um número impar \n";
        
    }

    }