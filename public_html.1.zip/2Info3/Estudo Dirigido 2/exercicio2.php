<?php

//Faça um algoritmo que peça um valor e mostre na tela se o valor é positivo ou negativo. 

    print "Digite um número: ";
    $n = fgets (STDIN);

    if ($n < 0){
        print "Esse número é negativo \n";
    }

    else{
        print "Esse número é positivo \n";
    }
    
