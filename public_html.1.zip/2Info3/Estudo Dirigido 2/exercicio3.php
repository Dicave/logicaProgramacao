<?php

    // Faça um algoritmo que verifique se uma letra digitada é "F" ou "M". Conforme a letra escrever: F - Feminino, M - Masculino, Sexo Inválido. 

    print "Qual o seu sexo? \n F ou M: ";
    $sexo = fgetc (STDIN);

    if (($sexo == 'F') or ($sexo == 'f')){
        print "Feminino \n";
    }

    elseif (($sexo == 'M') or ($sexo == 'm')){
        print "Masculino \n";
    } 

    else{
        print "Sexo Inválido \n";
    }