<?php 

    //Faça um algoritmo que verifique se uma letra digitada é vogal ou consoante. 

    print "Digite uma letra: ";
    $letra = fgetc (STDIN);

    if (($letra == 'a') or ($letra == 'A') or ($letra == 'e') or ($letra == 'E') or ($letra == 'i') 
    or ($letra == 'I') or ($letra == 'o') or ($letra == 'O') or ($letra == 'u') or ($letra == 'U')){
       print "$letra, é uma vogal! \n";
    }

    else{
        print "$letra, é uma consoante! \n";
    }
