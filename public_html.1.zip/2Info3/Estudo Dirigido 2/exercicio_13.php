<?php

for( $s1=100;$s1>=1;$s1--){
    print "$s1 \n";
}
