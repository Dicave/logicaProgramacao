<?php
//12. Faça um algoritmo que mostre os números de 1 a 100;

    $contador=0;

    while ($contador<100) {

        $contador++;
        print "$contador \n";

    }