<?php

print pow(2, 2);