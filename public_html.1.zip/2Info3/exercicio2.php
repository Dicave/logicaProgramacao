<?php

//Faça um programa dado 4 variáveis que (4 notas bimestrais), mostre a média//

print"Escreva a primeira nota:";

$primeira_nota = fgets(STDIN);

print"Escreva a segunda nota:";

$segunda_nota = fgets(STDIN);

print"Escreva a terceira nota:";

$terceira_nota = fgets(STDIN);

print"Escreva a quarta nota:";

$quarta_nota = fgets(STDIN);

$total_nota = ($primeira_nota + $segunda_nota + $terceira_nota + $quarta_nota)/4;

print "Total da soma: $total_nota";

