<?php

$menor_idade = false;

if ($menor_idade == false){
    print "Pode dirigir";
}