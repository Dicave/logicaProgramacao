<?php

//Faça um programa que dado duas variáveis, imprima a soma//

print"Escreva um número:";

//Float usa-se para número quebrado//
$primeiro_numero = (float) fgets(STDIN);

print"Escreva outro número:";

$segundo_numero = (float) fgets(STDIN);

$total_soma = $primeiro_numero + $segundo_numero;

print "Total da soma:". $total_soma ;

