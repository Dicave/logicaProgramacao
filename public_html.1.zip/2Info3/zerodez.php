<?php

   //faça um programa que peça uma nota entre zero e dez.Mostre uma mensagem caso valor seja invalido e continue pedindo até que o usuário informe um valor correto

   echo"Digite um valor entre 0 e 10: ";
   $nota = fgets(STDIN);
  while( $nota >0 or $nota <10 ){
       print"Meu Consagrado,é invalido!";
       while($nota <0 or $nota >10);
      
       print"Digite uma nota entre 0 e 10";\n;
    } 
    print "Você Acertou a $nota.  Meu Consagrado";