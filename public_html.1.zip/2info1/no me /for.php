<?php
$i=10;
for($i = 0; $i <=100; $i++){
        if($i>50 && $i < 60){
            continue;
        }
    print "$i\n";
}