<?php
    function Ola($nome){
        print "Olá $nome";
    }

    ola(fgets(STDIN));