<?php
    print "Digite o peso do cachorro em Kg:\n";
    $peso_cachorro = fgets(STDIN);

    if ($peso_cachorro <=2) {
        print "Esse cachorro late fino.\n";
    } elseif ($peso_cachorro <=10) {
        print "Esse cachorro tem um belo latido.\n";
    } elseif ($peso_cachorro >10) {
        print "Esse cachorro late grosso.\n";
    }