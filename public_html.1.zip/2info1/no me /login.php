<?php
    print"Digite o nome de usuário:";
    $usuario = fgets(STDIN);
    print"Digite a senha:";
    $senha = fgets(STDIN);

    while($usuario == $senha){
        print"Senha igual usuario, digite outra senha:";
        $senha = fgets(STDIN);
    }