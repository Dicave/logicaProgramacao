<?php

    print "digite a distancia";
    $distancia = fgets(STDIN)

    print "digite a velocidade";
    $velocidade = fgets(STDIN)

    $tempo = $distancia / $velocidade;

    print "seu tempo de viagem foi: $tempo";