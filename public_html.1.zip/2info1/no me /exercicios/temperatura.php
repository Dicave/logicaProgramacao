<?php

    print "digite temperatura C°";
    $c = fgets(STDIN);

    $f = 9*$c/5 + 32;

    print "temperatura em F° é: $f";