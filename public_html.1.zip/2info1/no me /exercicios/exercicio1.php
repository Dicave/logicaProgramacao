<?php
    $numero1 = fgets(STDIN);
    $numero2 = fgets(STDIN);

    print "O resultado foi: " . ($numero1 + $numero2);
