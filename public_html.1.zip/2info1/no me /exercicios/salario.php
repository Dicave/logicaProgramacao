<?php

    print "digite salario";
    $salario = fgets(STDIN);

    print "digite porcentagem do aumento";
    $porct = fgets(STDIN);

    $aumento = $novo_salario - $salario;
    $novo_salario = $salario + ($porct/100);

    print "valor do aumento é R$: $aumeto";

    print "seu novo salario é R$: $novo_salario";