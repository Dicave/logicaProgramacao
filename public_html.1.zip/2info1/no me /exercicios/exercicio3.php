<?php
    
   print "Digite o valor para A:";
   $a = fgets (STDIN);
   print "Digite o valor para B:";
   $b = fgets (STDIN);

   print "$a $b \n";
   list( $a, $b ) = [ $b, $a ];

   print "$a $b \n";
