<?php

    print "digite preço";
    $preco = fgets(STDIN);

    print "digite percentual de desconto";
    $desconto = fgets(STDIN);

    $preco_final = $preco - $desconto; 

    print " valor do desconto é: $desconto";
    print "valor a pagar é: $preco_final ";