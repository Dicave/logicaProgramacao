<?php   
    
    print "digite valor em metro";
    $metro = fgets(STDIN);

    $milimetro = $metro*1000;

    print "valor convertido é: $milimetro";