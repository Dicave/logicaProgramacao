<?php

    print"digite dias";
    $dias = fgets(STDIN);

    print"digite horas";
    $horas = fgets(STDIN);

    print"digite minutos";
    $minutos = fgets(STDIN);

    print"digite segundos";
    $segundos = fgets(STDIN);

    $total_segundos = ($dias*24*60*60) + ($horas*60*60) + ($minutos*60) + $segundos;

    print"total em segudos é: $total_segundos";
