<?php
    function cartaoVisita(){
        print "Lucas Viana\n";
        print"Rua. Cidade de Atalaia, nº 167\n";
        print"Estudante IFC- Araquari\n";
    }
