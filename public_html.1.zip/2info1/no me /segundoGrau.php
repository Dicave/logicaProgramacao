<?php
    print "Digite os valores para a,b,c:";
    $a = fgets(STDIN);
    $b = fgets(STDIN);
    $c = fgets(STDIN);

    $delta = pow($b,2) - 4* $a*$c;
    $x1 = (-$b + sqrt($delta))/2*$a;
    $x2 = (-$b - sqrt($delta))/2*$a;

    print "Valor de delta: $delta \n";
    print "Valor de x1: $x1 \n";
    print "Valor de x2: $x2 \n";