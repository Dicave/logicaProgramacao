from django.apps import AppConfig


class VitrineappConfig(AppConfig):
    name = 'vitrineapp'
