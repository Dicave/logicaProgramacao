<?php
    function versaoLinux(){
        print php_uname();
    }

    print versaoLinux;