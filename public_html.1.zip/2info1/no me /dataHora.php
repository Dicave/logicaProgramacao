<?php
    function DataHora(){
        date_default_timezone_set('America/Sao_Paulo');
        print "Data e hora atual: ". date("H:i:s d/m/Y"). "\n";
    }

    DataHora();