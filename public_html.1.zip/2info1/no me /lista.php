<?php
    $herois = array('Iron Man','SpiderMan','Hulk','Batman','Capitão América');

    for($i = 0, $j=1 ; $i < count($herois); $i++, $j++){
        print $j . "º lugar: " . $herois[$i] . "\n";
    }