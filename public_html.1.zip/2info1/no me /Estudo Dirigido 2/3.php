<?php
    print "Digite F ou M \n";
    $sexo = fgets(STDIN);

    if ($sexo == "F"){
        print "Sexo Feminino";
    }

    elseif ($sexo == "M"){
        print "Sexo Masculino";
    }

    else{
        print "Sexo Inválido";
    }