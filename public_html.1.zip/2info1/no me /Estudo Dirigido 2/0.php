<?php
    print PHP_INT_MIN;