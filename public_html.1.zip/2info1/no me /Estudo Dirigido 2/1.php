<?php
    print"Digite dois números:\n";
    $num1=fgets(STDIN);
    $num2=fgets(STDIN);

    if ($num1>$num2){
        print $num1;
    }

    else{
        print $num2;
    }
