<?php
    $i=100;

    for($i=100; $i >=1 ; $i--){
        print $i . "\n";
    }
