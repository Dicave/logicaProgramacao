<?php
    $i=1;

    for($i=1; $i <= 100; $i++){
        print $i . "\n";
    }
