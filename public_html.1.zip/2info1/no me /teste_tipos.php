<?php
    
    $maior_idade = 16 >= 8 and 1.49 >= 1.50;
    var_dump ($maior_idade);