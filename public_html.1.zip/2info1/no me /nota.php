<?php
    print"Digite uma nota entre 0 e 10:\n";
    $nota = fgets(STDIN);

    while($nota <0 or $nota >10){
        print "Valor invalido, digite novamente. \n";
        $nota = fgets(STDIN);
}

    print"Valor valido. \n"