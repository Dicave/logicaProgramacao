<?php
    $sorteio = rand(1,5);
    print"Digite um número entre 1 e 5: \n";
    $numero = (int) fgets(STDIN);

    while($sorteio != $numero){
        if ($sorteio > $numero) {
            print"O número informado é menor que o valor sorteado. \n";
        }else{
                print "O número informado é maior que o valor sorteado. \n";
        }

        print"Tente novamente:";
        $numero = (int) fgets(STDIN);
    }

    print"Você ganhou! \n";