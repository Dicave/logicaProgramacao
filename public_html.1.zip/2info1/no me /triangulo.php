<?php
    print 