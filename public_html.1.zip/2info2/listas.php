<?php

print "***TOP FIVE MELHORES HEROIS DO MUNDO*** \n";
$herois = array('Captain Marvel','Wonder Woman', 'Doctor Strange', 'Scarlet Wizard', 'Thor' );

for ($i=0; $i < 5; $i++){
    print ($i + 1) . "º lugar: " . $herois[$i];
    print"\n";
    sleep(1.5);
}

print "\n";

/*
$cu = "carol";
print $cu[3]; mostra a 3ª letra
strlen conta o lenght
php.net/manual/pt_br/ref_array.com