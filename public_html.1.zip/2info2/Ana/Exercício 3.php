<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8" />
<title>Formulário de Contato Demo</title>
</head>

<body>

<div id="stylized" class="myform">
<form id="form1" id="form3" action="mail.php" method="POST">

<br />

<label> Digite um número: 
<input type="text" name="numero">
</label>

<br />
<br />

<button type="submit" value="Enviar" style="margin-top:15px;">Enviar</button>

</div> 
</body>
</html>