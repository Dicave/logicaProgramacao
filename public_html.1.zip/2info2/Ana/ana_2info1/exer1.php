?php

float temp(float c, float f) {
    c= (f - 32) * 5/9;
}

int maim()
    int i;
    float x, y;
    for (i=;i<=10;i++)
        printf("Digite tem em F");
scanf("%f", &f)
print("a temp Celcius é: %f\n")
temp(c);
 return 0: }
