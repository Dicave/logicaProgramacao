<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8" />
<title>Formulário Pessoal</title>
</<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8" />
<title>Formulário de Contato Demo</title>
</head>

<body>

<div id="stylized" class="myform">
<form id="form1" id="form3" action="mail.php" method="POST">

<br />

<label> Digite um número: 
<input type="text" name="numero">
</label>

<br />
<br />

<button type="submit" value="Enviar" style="margin-top:15px;">Enviar</button>

</div> 
</body>
</html>head>

<body>
<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8" />
<title>Formulário de Contato Demo</title>
</head>

<body>

<div id="stylized" class="myform">
<form id="form1" id="form3" action="mail.php" method="POST">

<br />

<label> Digite um número: 
<input type="text" name="numero">
</label>

<br />
<br />

<button type="submit" value="Enviar" style="margin-top:15px;">Enviar</button>

</div> 
</body>
</html>
<d<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8" />
<title>Formulário de Contato Demo</title>
</head>

<body>

<div id="stylized" class="myform">
<form id="form1" id="form3" action="mail.php" method="POST">

<br />

<label> Digite um número: 
<input type="text" name="numero">
</label>

<br />
<br />

<button type="submit" value="Enviar" style="margin-top:15px;">Enviar</button>

</div> 
</body>
</html>iv id="stylized" class="myform">
<f<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8" />
<title>Formulário de Contato Demo</title>
</head>

<body>

<div id="stylized" class="myform">
<form id="form1" id="form3" action="mail.php" method="POST">

<br />

<label> Digite um número: 
<input type="text" name="numero">
</label>

<br />
<br />

<button type="submit" value="Enviar" style="margin-top:15px;">Enviar</button>

</div> 
</body>
</html>orm id="form1" id="form1" action="mail.php" method="POST">
<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8" />
<title>Formulário de Contato Demo</title>
</head>

<body>

<div id="stylized" class="myform">
<form id="form1" id="form3" action="mail.php" method="POST">

<br />

<label> Digite um número: 
<input type="text" name="numero">
</label>

<br />
<br />

<button type="submit" value="Enviar" style="margin-top:15px;">Enviar</button>

</div> 
</body>
</html>
<b<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8" />
<title>Formulário de Contato Demo</title>
</head>

<body>

<div id="stylized" class="myform">
<form id="form1" id="form3" action="mail.php" method="POST">

<br />

<label> Digite um número: 
<input type="text" name="numero">
</label>

<br />
<br />

<button type="submit" value="Enviar" style="margin-top:15px;">Enviar</button>

</div> 
</body>
</html>r />
<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8" />
<title>Formulário de Contato Demo</title>
</head>

<body>

<div id="stylized" class="myform">
<form id="form1" id="form3" action="mail.php" method="POST">

<br />

<label> Digite um número: 
<input type="text" name="numero">
</label>

<br />
<br />

<button type="submit" value="Enviar" style="margin-top:15px;">Enviar</button>

</div> 
</body>
</html>
<l<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8" />
<title>Formulário de Contato Demo</title>
</head>

<body>

<div id="stylized" class="myform">
<form id="form1" id="form3" action="mail.php" method="POST">

<br />

<label> Digite um número: 
<input type="text" name="numero">
</label>

<br />
<br />

<button type="submit" value="Enviar" style="margin-top:15px;">Enviar</button>

</div> 
</body>
</html>abel>Nome:
<i<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8" />
<title>Formulário de Contato Demo</title>
</head>

<body>

<div id="stylized" class="myform">
<form id="form1" id="form3" action="mail.php" method="POST">

<br />

<label> Digite um número: 
<input type="text" name="numero">
</label>

<br />
<br />

<button type="submit" value="Enviar" style="margin-top:15px;">Enviar</button>

</div> 
</body>
</html>nput type="text" name="nome">
</<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8" />
<title>Formulário de Contato Demo</title>
</head>

<body>

<div id="stylized" class="myform">
<form id="form1" id="form3" action="mail.php" method="POST">

<br />

<label> Digite um número: 
<input type="text" name="numero">
</label>

<br />
<br />

<button type="submit" value="Enviar" style="margin-top:15px;">Enviar</button>

</div> 
</body>
</html>label>

<br />
<br />


<label>Endereço:
<input type="text" name="endereco">
</label>

<br />
<br />


<label>CEP:
<input type="text" name="cep">
</label>

<br />
<br />


<label> Cidade: 
<select name="Cidade" size="1">
<option value="nada"></option>
<option value="Joinville">Joinville</option>
<option value="Araquari">Araquari</option>
<option value="São Francisco do Sul">São Francisco do Sul</option>
<option value="Barra Velha">Barra Velha</option>
<option value="Barra do Sul">Barra do Sul</option>
<option value="Piçarras">Piçarras</option>
</select>

<br />

<p>Sexo:</p>

<label>Feminino:
<input type="radio" name="cep">
</label>

<br />

<label>Masculino:
<input type="radio" name="cep">
</label>

<br />
<br />

<label> Cartão de crédito: 
<select name="Cidade" size="1">
<option value="nada"></option>
<option value="Visa">Visa</option>
<option value="Elo">Elo</option>
<option value="Diners Club International">Diners Club International</option>
<option value="Mastercard">Mastercard</option>
<option value="Cielo">Cielo</option>
<option value="American Exppress">American Express</option>
</select>


<label>Número do cartão:
<input type="text" name="cep">
</label>

<br />
<br />

<button type="submit" value="Enviar" style="margin-top:15px;">Enviar</button>

</div> 
</body>
</html>















