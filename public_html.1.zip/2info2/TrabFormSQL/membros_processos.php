<?php
//Conectar–se ao BD
$dbhost = 'localhost';
$dbuser = 'aluno';
$dbpassword = 'aluno';
$dbname = 'atv_prt_041_bd';
//Efetua a conexão com o BD
$link = mysqli_connect($dbhost, $dbuser, $dbpassword, $dbname) or die('Error
connecting to MySQL Server.');
//Obtém os valores do formulário
$e_mail = 'email';
$nome = 'nome';
$escola = 'escola';
$funcao = 'funcao';
$numero_equipe = 'num';
//Cria a Query SQL
$query = "INSERT INTO feedback (email, nome,escola,num,
feedback_date) VALUES ('$e_mail', '$nome', 'escola', '$numero_equipe', NOW()
)";
$result = mysqli_query( $link, $query ) or die('Error querying database.');
//Fechar a conexão com o BD
mysqli_close($link);

?>