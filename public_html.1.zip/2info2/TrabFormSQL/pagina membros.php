<!DOCTYPE html>
<html>
<head>
<title>Página de Cadastro</title>
</head>
<body>
<form action="membros_processos.php" method="post">
<table>
<tr>
<td colspan="2"><h2>Dite suas Informações</h2></td>
</tr>
<tr>
<td><p><strong>E-mail:</strong></p></td>
<td><input type="text" name="e_mail" size="30" maxlength="30" /></td>
</tr>
<tr>
<td><p><strong>Nome:</strong></p></td>
<td><input type="text" name="nome" size="30" /></td>
</tr>
<tr>
<td><p><strong>Escola</strong></p></td>
<td><input type="text" name="escola" size="40"/></td>
</tr>
<tr>
<td><p><strong>Função:</strong></p></td>
<td><textarea name="funcao" rows="7" cols="48"/></textarea></td>
</tr>
<tr>
<td></td>
<td><p><strong>Numero da equipe:</strong></p></td>
<td><td><input type="text" name="numero_equipe" size="30" maxlength="30" /></td>
</tr>
<tr>
<td></td>
<td><input type="submit" name="submit" value="Enviar" /></td>
</tr>
</table>
</form>
</body>
</html>