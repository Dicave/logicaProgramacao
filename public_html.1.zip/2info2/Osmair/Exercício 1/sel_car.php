<!DOCTYPE <!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8" />
    <title>Seletor de carros</title>
</head>

<body>
    <h2>Sucesso</h2>
   <?php

    // get form input
   $tipo = $_POST ['selTipo'];
   $cor = $_POST ['txtCor'];

   // use form input
   echo "Seu $tipo de cor $cor está pronto. Dirija com cuidado!";
   ?>
</body>
</html>