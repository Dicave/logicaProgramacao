<!DOCTYPE <!DOCTYPE html>
<html>
<head>
    <title>Seletor de cores interativo</title>
    <meta charset="utf-8" />
</head>
<body>
    <h2>Seletor de cores interativo</h2>
    <form method="post" action="sel_cor.php">

    <br/>
    <br/>

    <label>R
    <input type="text" name="R">
    </label>

    <br/>
    <br/>

    <label>G
    <input type="text" name="G">
    </label>

    <br/>
    <br/>

    <label>B
    <input type="text" name="B">

    <br/>
    <br/>

   <input type = "submit" name = "Enviar" />
   
</form>
</body>
</html>