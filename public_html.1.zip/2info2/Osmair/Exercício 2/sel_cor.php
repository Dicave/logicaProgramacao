<!DOCTYPE <!DOCTYPE html>
<html>
<head>
    <title>Seletor de cores interativo</title>
</head>

<body>
    <h2>Seletor de cores interativo</h2>
    <?php
        //Get input values
        $r = $_POST['R'];
        $g = $_POST['G'];
        $b = $_POST['B'];

        //Generate RGB string from input
        $rgb = $r . ',' . $g . ',' . $b;
    ?>
    R: <?php echo $r; ?>
    G: <?php echo $g; ?>
    B: <?php echo $b; ?>
    <br /><br />
    <div style="width: 150px; height: 150px; background-color: rgb(<?php echo $rgb; ?>)" /></div>


</body>
</html>