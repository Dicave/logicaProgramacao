
<?php

for ($a = 0; $a < 8; $a++) { 

    print "* * * * * * * * \n";

}

print "\n";

