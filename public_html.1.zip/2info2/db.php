<?php
$query = mysqli_connect("localhost","root",”root”,“pc_db”);
?>