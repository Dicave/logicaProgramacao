<html>
<?php
include('db.php');
$query = mysqli_query($conn, "select * from tb_pc");
$row = mysqli_fetch_array($query);

echo $row['id'];
echo $row['username'];
echo $row['password'];
echo "\n";
echo $row[0];
echo $row[1];
echo $row[2];

?>
</html>