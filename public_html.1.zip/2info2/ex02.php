<html>
<?php
include('db.php');
$query = mysqli_query($conn, "select * from tb_pc");

$row = mysqli_fetch_assoc($query);

echo $row['id'];
echo $row['username'];
echo $row['password'];

?>

</html>