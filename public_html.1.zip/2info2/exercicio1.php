<?php

$n = 1;

while ($n < 5) { 
    print "Digite um número";
    $n1 = (float) fgets (STDIN);
}

if ($n > 5) {
    print "Soma dos números: $n";
}


