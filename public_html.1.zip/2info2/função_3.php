<?php

$aumento = 0.08;

function calcularAumento ($salario)  {
    global $aumento;
    $salario = $salario + ($salario * $aumento);
    print "Seu salário com aumento é: $salario \n";
}

calcularAUmento (1000.00);