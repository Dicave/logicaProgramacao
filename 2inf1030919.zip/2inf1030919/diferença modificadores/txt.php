<?php
//prog orientada obj


//quem esta fora para nao ter acesso a todos os privador faz uma validação
 //setters propiedade peivada usa  poem   .colocar valor dentro da propiedade podem acessar a propiedade private porque estao dentro da celula 

 //getter puxa a propedades  tira 

 class Funcionario{
    public $nome = 'Alex';
    protected  $salario = 200;
    private $rg ='00.000.000-0';
   }
   //

 1. Nós usamos o modificador de acesso private a fim de:
 'X'a) Limitar o acesso a uma classe
    b) Limitar o acesso às propriedades
    c) Limitar o acesso aos métodos
    d) B e C estão corretas
    Exercício de codificação
    Vamos voltar para a classe Usuario que desenvolvemos nas atividades anteriores. Agora vamos definir o
    $primeiroNome do usuário como uma propriedade privada (private).
    Esta é a classe Usuario:
    class Usuario {
    // seu código vai aqui
    }
    2. Crie uma propriedade na classe Usuario chamada $primeiroNome e evite que qualquer código
    de fora da classe altere o seu valor, usando o modificador de acesso apropriado.
    3. Crie um método para definir o valor da propriedade $primeiroNome. Use o modificador de acesso
    correto para ele.
    4. Agora, crie um método para retornar o valor $primeiroNome.
    5. Crie um novo objeto chamado $usuario1. Depois defina seu primeiro nome como "Joe" e faça
    com que ele retorne este nome.

?>