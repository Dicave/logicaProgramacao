<?php





abstract class usuario{

    protected $nomeUsuario;


abstract public function declararSeuPapel();
public function setnomeUsuario($nome)

{
this ->nomeUsuario = $nome;
}

public function getnomeUsuario()
{
    return $this ->nomeUsuario;
}

//public function setMediaAnual($media) {
  //  $this->mediaAnual = $media;
?>