
	<section id="rodape">
	<hr>
	<p>A partir daqui é o arquivo rodape.html</p>
		<div class="endereco">
			BR-280 km 27
		</div>
	</section>
</body>
</html>