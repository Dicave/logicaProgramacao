<!DOCTYPE html>
<html>
<head>
	<title>Exemplo - Manipulação de Arquivos</title>
	<link rel="stylesheet" type="text/css" href="estilo.css">
</head>
<body>
<?php
	print(date("d/m/Y"));
?>
	<section id="cabecalho">
		<div class="logo">
		</div>
		<div class="titulo">
			Manipulação de arquivos
		</div>
		<p>Até aqui é o conteúdo do cabecalho.html</p>
		<hr>
	</section>


