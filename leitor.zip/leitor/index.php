<?php
	$cabecalho= file_get_contents("cabeçalho.html");
	print($cabecalho);
?>
<button class="ui negative basic button">Negative</button>

<img class="ui avatar image" src="chicago.jpg">
<span>Username</span>





	<section id="noticias" class="row"> </section>
		<div class="column four wide">
			<p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. At minus laudantium accusantium atque quibusdam ipsum mollitia provident ullam eos excepturi, dolorum illo voluptatibus vero cum voluptates aliquid eius ipsa praesentium!</p>
		</div>
		<div class="column twelve wide">
			<p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod
			tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam,
			quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo
			consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse
			cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non
			proident, sunt in culpa qui officia deserunt mollit anim id est laborum.</p>
			<p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod
			tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam,
			quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo
			consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse
			cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non
			proident, sunt in culpa qui officia deserunt mollit anim id est laborum.</p>
		</div>
    <div class="dropdown">
  <button id="dLabel" type="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
    Dropdown trigger
    <span class="caret"></span>
  </button>
  <ul class="dropdown-menu" aria-labelledby="dLabel">
    ...
  </ul>
</div>
<iframe width="560" height="310" src="https://www.youtube.com/embed/wjnbYq0ag-M" frameborder="0" allowfullscreen></iframe>

		<section id="mais-lidas" class="row">
			<div class="col-md-12">

				<div id="myCarousel" class="carousel slide" data-ride="carousel">
				  <!-- Indicators -->
				  <ol class="carousel-indicators">
				    <li data-target="#myCarousel" data-slide-to="0" class="active"></li>
				    <li data-target="#myCarousel" data-slide-to="1"></li>
				    <li data-target="#myCarousel" data-slide-to="2"></li>
				  </ol>

				  <!-- Wrapper for slides -->
				  <div class="carousel-inner">
				    <div class="item active">
				      <img src="la.jpg" alt="Los Angeles">
				    </div>

				    <div class="item">
				      <img src="chicago.jpg" alt="Chicago">
				    </div>

				    <div class="item">
				      <img src="ny.jpg" alt="New York">
				    </div>
				  </div>

				  <!-- Left and right controls -->
				  <a class="left carousel-control" href="#myCarousel" data-slide="prev">
				    <span class="glyphicon glyphicon-chevron-left"></span>
				    <span class="sr-only">Previous</span>
				  </a>
				  <a class="right carousel-control" href="#myCarousel" data-slide="next">
				    <span class="glyphicon glyphicon-chevron-right"></span>
				    <span class="sr-only">Next</span>
				  </a>
				</div>
			</div>
		</section>

<?php
	$rodape= file_get_contents($rodape);
	print($rodape);
?>