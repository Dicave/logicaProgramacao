<?php
print("Conversor celsius -> fahrenheit");

function fartocel ($tf)
{
        $tc = ($tf - 32) * 5/9;
        return $tc;

}
print("digite uma temperatura em Fahrenheit");
$tf= (float) fgets(STDIN);
$tc = fartocel($tf);
print($tf."Fahrenheits equivale a ".$tc."Celsius");
?>