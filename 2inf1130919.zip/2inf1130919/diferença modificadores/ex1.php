<?php   

class primeiroNome{

    private $primeiroNome ='';
}
?>