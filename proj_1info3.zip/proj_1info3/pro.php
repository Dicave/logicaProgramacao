<?php
//siape = matricula
function listaprofessores(){

}
function buscaprofessor(){

}

?>