<?php

include("cabecalho.php");
include("alunos.php");	
?>

<article class="coluna80">
	
<?php
foreach ($variable as $key => $value) {
	
}
$turma = '1info' .$i;
?>


<section class="lista"> </section>


}
