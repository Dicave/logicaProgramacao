<?php

//array criado automaticamente contendo as variaveis enviadas por metodo POST
print_r($_POST);



$siape = $_POST['siape'];
$nome = $_POST['nome'];
$email = $_POST['email'];
$foto = $_POST['foto'];


$texto= $siape.",".$nome.",".$email.",".$foto;

print($texto);


//abrir o arquivo professores.csv  em modo de escrita

$arquivo = fopen("dados/professores.csv", "a+");
//Escrevendo no arquivo//a+ abre e posiciona o ponteiro no final do arquivo 
fwrite($arquivo,"\n".$texto);
//fechar o arquivo
fclose($arquivo);

print("acho que escreveu");


?>

<h2>Contato inserido</h2>

<meta http-equiv="refresh" content="3;URL=cabecalho.php">