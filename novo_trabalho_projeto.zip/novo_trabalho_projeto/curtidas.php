<?php

$json = file_get_contents("dados/curtidas.json");
$lista_curtidas = json_decode($json,true);

if ($_GET['id']==1 and $_GET['sera']=='curtir') {
	$curtidas=$lista_curtidas[0]['numero_curtidas'];
	$curtidas=$curtidas+1;
	$lista_curtidas[0]['numero_curtidas']=$curtidas;
	$json=json_encode($lista_curtidas,JSON_PRETTY_PRINT);
	file_put_contents("dados/curtidas.json",$json);
	header('Location:conteudo.php?curtir=1&id=0');
}elseif($_GET['id']==2) {
	$curtidas=$lista_curtidas[1]['numero_curtidas'];
	$curtidas=$curtidas+1;
	$lista_curtidas[1]['numero_curtidas']=$curtidas;
	$json=json_encode($lista_curtidas,JSON_PRETTY_PRINT);
	file_put_contents("dados/curtidas.json",$json);
	header('Location:conteudo.php?curtir=1&id=1');
}elseif($_GET['id']==3) {
	$curtidas=$lista_curtidas[2]['numero_curtidas'];
	$curtidas=$curtidas+1;
	$lista_curtidas[2]['numero_curtidas']=$curtidas;
	$json=json_encode($lista_curtidas,JSON_PRETTY_PRINT);
	file_put_contents("dados/curtidas.json",$json);
	header('Location:conteudo.php?curtir=1&id=2');
}elseif($_GET['id']==4) {
	$curtidas=$lista_curtidas[3]['numero_curtidas'];
	$curtidas=$curtidas+1;
	$lista_curtidas[3]['numero_curtidas']=$curtidas;
	$json=json_encode($lista_curtidas,JSON_PRETTY_PRINT);
	file_put_contents("dados/curtidas.json",$json);
	header('Location:conteudo.php?curtir=1&id=3');
}elseif($_GET['id']==5) {
	$curtidas=$lista_curtidas[4]['numero_curtidas'];
	$curtidas=$curtidas+1;
	$lista_curtidas[4]['numero_curtidas']=$curtidas;
	$json=json_encode($lista_curtidas,JSON_PRETTY_PRINT);
	file_put_contents("dados/curtidas.json",$json);
	header('Location:conteudo.php?curtir=1&id=4');
}elseif($_GET['id']==6) {
	$curtidas=$lista_curtidas[5]['numero_curtidas'];
	$curtidas=$curtidas+1;
	$lista_curtidas[5]['numero_curtidas']=$curtidas;
	$json=json_encode($lista_curtidas,JSON_PRETTY_PRINT);
	file_put_contents("dados/curtidas.json",$json);
	header('Location:conteudo.php?curtir=1&id=5');
}elseif($_GET['id']==7) {
	$curtidas=$lista_curtidas[6]['numero_curtidas'];
	$curtidas=$curtidas+1;
	$lista_curtidas[6]['numero_curtidas']=$curtidas;
	$json=json_encode($lista_curtidas,JSON_PRETTY_PRINT);
	file_put_contents("dados/curtidas.json",$json);
	header('Location:conteudo.php?curtir=1&id=6');
}elseif($_GET['id']==8) {
	$curtidas=$lista_curtidas[7]['numero_curtidas'];
	$curtidas=$curtidas+1;
	$lista_curtidas[7]['numero_curtidas']=$curtidas;
	$json=json_encode($lista_curtidas,JSON_PRETTY_PRINT);
	file_put_contents("dados/curtidas.json",$json);
	header('Location:conteudo.php?curtir=1&id=7');
}elseif($_GET['id']==9) {
	$curtidas=$lista_curtidas[8]['numero_curtidas'];
	$curtidas=$curtidas+1;
	$lista_curtidas[8]['numero_curtidas']=$curtidas;
	$json=json_encode($lista_curtidas,JSON_PRETTY_PRINT);
	file_put_contents("dados/curtidas.json",$json);
	header('Location:conteudo.php?curtir=1&id=8');
}elseif($_GET['id']==10) {
	$curtidas=$lista_curtidas[9]['numero_curtidas'];
	$curtidas=$curtidas+1;
	$lista_curtidas[9]['numero_curtidas']=$curtidas;
	$json=json_encode($lista_curtidas,JSON_PRETTY_PRINT);
	file_put_contents("dados/curtidas.json",$json);
	header('Location:conteudo.php?curtir=1&id=9');
}

?>