
</body>
<div class="divisor"></div>
	<footer class="rodapeback">
		<h4 class="rodape">Nostalgia ® todos os direitos reservados</h4>
			<div class="divisor"></div>
			<section  class="imgrodape">
			<img src="logos/rodape1.png" class="imgrdp">
			<img src="logos/rodape2.png" class="imgrdp">
		</section>
	</footer>
</html>