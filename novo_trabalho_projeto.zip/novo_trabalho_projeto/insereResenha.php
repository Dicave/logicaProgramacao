<?php


$nomeArquivo = date('dmYHis').$_FILES['foto']['name'];

	$origem = $_FILES['foto']['tmp_name'];

	$destino = "imagens/resenhas/".$nomeArquivo;

	move_uploaded_file($origem, $destino);

	$dados = array(
		"codigo" => uniqid(),
		"nome" => $_POST['nome'],
		"sinopse" => $_POST['sinopse'],
		"comentario" => $_POST['comentario'],
		"lancamento" => $_POST['lancamento'],
		"foto" => $destino
	);

	$json = json_encode($dados);

	$arquivo = fopen("dados/dados.json","a+");

	fwrite($arquivo, $json);

	fclose($arquivo);

	echo('<meta http-equiv="refresh" content="0;url=resenha.php">');

?>