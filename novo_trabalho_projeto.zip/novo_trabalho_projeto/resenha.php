<?php
include ("cabecalho.php");

    $json = file_get_contents("dados/dados.json");

    $listaResenha = json_decode($json, true);
    sort($listaResenha);
?>


?>


<table>
    <tr>
        <th>Resenhas</th>
        <th>Excluir</th>
        <th>Editar</th>

    </tr>


        <tr>
            <td>
            	<section class="item">
					<a href="conteudo1.php"><img src="imagens/mario.png"></a>
				<div class="divisor"></div>
					<a href="conteudo1.php" class="titulo UpheavalPro"><p>Mario</p></a>
                </section>
                    <p id="descricao">Mario, também conhecido como Super Mario, é um personagem fictício e o protagonista principal da série de videogames, criado pelo designer de jogos japonês Shigeru Miyamoto. Mario é o mascote oficial da Nintendo, e da FriendZone, sempre salvando a Princess Peach, por um beijo na bochecha tendo a sua aparição em mais de 80 jogos desde a sua criação.</p>
			</td>
            <td><img src="imagens/excluir.png" id="excluir_editar"></td>
            <td><img src="imagens/editar.png" id="excluir_editar"></td>
        </tr>

        <tr>
        	<td>
        		<section class="item">
					<a href="conteudo2.php"><img src="imagens/pacman.png"></a>
				<div class="divisor"></div>
					<a href="conteudo2.php" class="titulo UpheavalPro"><p>PacMan</p></a>
				</section>
                <p id="descricao">É um jogo eletrônico criado pelo Tōru Iwatani para a empresa Namco, e sendo distribuído para o mercado americano pela Midway Games. Produzido originalmente para Arcade no início dos anos 1980, tornou-se um dos jogos mais jogados e populares no momento, tendo versões para diversos consoles e continuações para tantos outros, inclusive na atualidade</p>
        	</td>
        	<td><img src="imagens/excluir.png" id="excluir_editar"></td>
            <td><img src="imagens/editar.png" id="excluir_editar"></td>
        </tr>

        <tr>
        	<td>
        		<section class="item">
					<a href="conteudo3.php"><img src="imagens/sonic.png"></a>
				<div class="divisor"></div>
					<a href="conteudo3.php" class="titulo UpheavalPro"><p>Sonic</p></a>
				</section>
                <p id="descricao">É uma franquia de jogos criada e produzida pela Sega. A franquia é centrada em uma série de jogos de plataforma focados em velocidade. O protagonizada da série é um ouriço azul chamado Sonic, cuja vida pacífica é sempre interrompida pelo antagonista principal da série, Dr. Eggman</p>
        	</td>
        	<td><img src="imagens/excluir.png" id="excluir_editar"></td>
            <td><img src="imagens/editar.png" id="excluir_editar"></td>
        </tr>

        <tr>
        	<td>
        		<section class="item">
					<a href="conteudo4.php"><img src="imagens/donkey.png"></a>
				<div class="divisor"></div>
					<a href="conteudo4.php" class="titulo UpheavalPro"><p>Donkey Kong</p></a>
				</section>
                <p id="descricao">Donkey Kong foi o primeiro exemplo de jogo estilo plataforma. Algumas vezes caracterizado como o primeiro jogo de plataforma da história, de fato é que foi o primeiro jogo de plataforma a utilizar o pulo como habilidade, introduzindo a necessidade de pular entre brechas, obstáculos e inimigos próximos.</p>
        	</td>
        	<td><img src="imagens/excluir.png" id="excluir_editar"></td>
            <td><img src="imagens/editar.png" id="excluir_editar"></td>
        </tr>


</table>
	


<?php
include ("rodape.php");
?>