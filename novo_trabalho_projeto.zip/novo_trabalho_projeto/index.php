<?php 
include("cabecalho.php");
?>
	<div class="divisor"></div>
	<form id="pesquisar" action="procura.php" method="get">
		<input type="search" name="pesq" placeholder="pesquisar" id="item_pesq">
		<input type="submit" name="enviar" id="pesq_env">
	</form>

	<div class="divisor"</div>

		<div class="item">
			<a href="conteudo.php?id=0"><img src="imagens/Mario.png"></a>
			<div class="divisor"></div>
			<a href="conteudo.php?id=0" class="titulo UpheavalPro"><p>Mario</p></a>
		</div>

		<div class="item">
			<a href="conteudo.php?id=1"><img src="imagens/Pac Man.png"></a>
			<div class="divisor"></div>
			<a href="conteudo.php?id=1" class="titulo UpheavalPro"><p>Pac Man</p></a>
		</div>

		<div class="item">
			<a href="conteudo.php?id=2"><img src="imagens/Sonic.png"></a>
			<div class="divisor"></div>
			<a href="conteudo.php?id=2" class="titulo UpheavalPro"><p>Sonic</p></a>
		</div>

		<div class="item">
			<a href="conteudo.php?id=3"><img src="imagens/Donkey Kong.png"></a>
			<div class="divisor"></div>
			<a href="conteudo.php?id=3" class="titulo UpheavalPro"><p>Donkey Kong</p></a>
		</div>
	
		<div class="item">
			<a href="conteudo.php?id=4"><img src="imagens/Street Fighter.png"></a>
			<div class="divisor"></div>
			<a href="conteudo.php?id=4" class="titulo UpheavalPro"><p>Street Fighter</p></a>
		</div>


		<div class="item">
			<a href="conteudo.php?id=5"><img src="imagens/Mortal Kombat.png"></a>
			<div class="divisor?"></div>
			<a href="conteudo.php?id=5" class="titulo UpheavalPro"><p>Mortal Kombat</p></a>
		</div>

		<div class="item">
			<a href="conteudo.php?id=6"><img src="imagens/Space Invaders.png"></a>
			<div class="divisor"></div>
			<a href="conteudo.php?id=6" class="titulo UpheavalPro"><p>Space Invaders</p></a>
		</div>

		<div class="item">
			<a href="conteudo.php?id=7"><img src="imagens/Asteroids.png"></a>
			<div class="divisor"></div>
			<a href="conteudo.php?id=7" class="titulo UpheavalPro"><p>Asteroids</p></a>
		</div>

		<div class="item">
			<a href="conteudo.php?id=8"><img src="imagens/Pole Position II.png"></a>
			<div class="divisor"></div>
			<a href="conteudo.php?id=8" class="titulo UpheavalPro"><p>Pole Position II</p></a>
		</div>

		<div class="item2">
			<a href="conteudo.php?id=9"><img src="imagens/Teenage Mutant Ninja Turtles.png"></a>
			<div class="divisor"></div>
			<a href="conteudo.php?id=9" class="titulo UpheavalPro"><p>Teenage Mutant Ninja Turtles</p></a>
		</div>
		
<?php
include("rodape.php");
?>