<?php

function buscaResenha($codigo){
	$resenha= array();

	$dados = file("dados/dados.json");
	foreach ($dados as $posicao => $linha) {
		$colunas = explode(",", $linha);
		if ($colunas[0] == $codigo) {
			$resenha['codigo'] = $colunas[0];
			$resenha['nome'] = $colunas[1];
			$resenha['sinospe'] = $colunas[2];
			$resenha['comentario'] = $colunas[3];
			$resenha['lancamento'] = $colunas[4];
			$resenha['foto'] = $colunas[5];
		}
	}
	return $resenha;
}

function listaResenhas(){
	$resenhas = array();
	$dados = file("dados/dados.json");
	foreach ($dados as $posicao => $linha) {
		if ($posicao != 0) {
			$colunas = explode(",", $linha);
			$resenha = array();
			$resenha['codigo'] = $colunas[0];
			$resenha['nome'] = $colunas[1];
			$resenha['sinopse'] = $colunas[2];
			$resenha['comentario'] = $colunas[3];
			$resenha['lancamento'] = $colunas[4];
			$resenha['foto'] = $colunas[5];
			$resenhas[] = $resenha;
		}
	}

	return $resenhas;
}

?>