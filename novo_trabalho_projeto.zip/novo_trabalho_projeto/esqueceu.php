<?php
include("cabecalho.php");
?>

<h1 class="UpheavalPro" id="titulo_esqueceu">Esqueceu a sua senha?</h1>
<div class="divisor"></div>

	<form id="formulario">
<label class="corlabel labels" for="email">Coloque seu e-mail no campo abaixo para a confirmação de troca de senha:</label>
<div class="divisor"></div>
<br>
		<input type="email" name="email" placeholder="digite seu e-mail" class="inputs">
		<input type="submit" name="enviar" id="enviar2">
	</form>

<?php
include("rodape.php");
?>
