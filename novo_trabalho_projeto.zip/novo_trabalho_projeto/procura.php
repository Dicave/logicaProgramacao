
<?php 
if($_GET['pesq']=='mario'){
 	include("conteudo1.php");
}elseif($_GET['pesq']=='pac man'){
	include("conteudo2.php");
}elseif($_GET['pesq']=="sonic"){
	include("conteudo3.php");
}elseif($_GET['pesq']=="donkey kong"){
	include("conteudo4.php");
}elseif($_GET['pesq']=="street fighter"){
	include("conteudo5.php");
}elseif($_GET['pesq']=="mortal kombat"){
	include("conteudo6.php");
}elseif($_GET['pesq']=="space invaders"){
	include("conteudo7.php");
}elseif($_GET['pesq']=="asteroids"){
	include("conteudo8.php");
}elseif($_GET['pesq']=="pole position 2"){
	include("conteudo9.php");
}elseif($_GET['pesq']=="teenage mutant ninja turtles"){
	include("conteudo10.php");
}


?>
