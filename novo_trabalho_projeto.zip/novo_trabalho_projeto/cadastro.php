<?php
include ("cabecalho.php");
?>
		<div class="divisor"></div>
			<h1 id="titulocont" class="UpheavalPro">Crie sua nova conta</h1>
		<div class="divisor"></div>
				<form action="dados.csv" id="formulario">
					<label class="labels" for="nome"><h3>Nome</h3></label>
			<div class="divisor"></div>
					<input class="inputs" type="text" name="nome">
		<div class="divisor"></div>
					<label class="labels" for="nickname"><h3>NickName</h3></label>
			<div class="divisor"></div>
					<input class="inputs" type="text" name="nickname">
		<div class="divisor"></div>
					<label class="labels" for="email"><h3>E-mail</h3></label>
			<div class="divisor"></div>
					<input class="inputs" type="email" name="email">
		<div class="divisor"></div>
					<label class="labels" for="senha"><h3>Senha</h3></label>
			<div class="divisor"></div>
					<input class="inputs" type="password" name="senha">
		<div class="divisor"></div>
					<label class="labels" for="confirmar"><h3>Confirmar Senha</h3></label>
			<div class="divisor"></div>
					<input class="inputs" type="password" name="confirmar">
		<div class="divisor"></div>
					<input id="enviar2" type="submit" name="enviar">
				</form>
<?php
include ("rodape.php");
?>