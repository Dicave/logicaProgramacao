<?php 

//iniciar a session
session_start();

$login = $_POST['login'];
$senha = $_POST['senha'];

//verificar se usuario == "abc" e senha =="123"

if ($login == "abc" and $senha == "123") {
	echo("Olá, Administrador!!");

//gravando
	$_SESSION['login'] = 'admin';
	$_SESSION['nome'] = 'administrador';

	//redirecionar para a pagina restrita do adm
	echo('<meta http-equiv="refresh" content="1;url=index.php">');
}else{
	echo("Dados Inválidos!!");
	//redirecionar para a página inicial
	echo('<meta http-equiv="refresh" content="2;url=index.php">');
}





?>