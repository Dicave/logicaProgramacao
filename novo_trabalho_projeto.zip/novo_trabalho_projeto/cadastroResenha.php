<?php
include ("cabecalho.php");
?>
	<div class="divisor"></div>
	<h1 id="titulocont" class="UpheavalPro">Cadastro Resenha</h1>
	<form method="post" action="insereResenha.php" enctype="multipart/form-data" id="formulario">
						<label class="labels" for="nome"><h3>Nome da Resenha</h3></label>
				<div class="divisor"></div>
						<input class="inputs" type="text" name="nome">
			<div class="divisor"></div>
						<label for="foto" class="labels"><h3>Escolher Foto</h3></label>
						<input type="file" name="foto" class="imagem inputs">
			<div class="divisor"></div>
						<label class="labels" for="sinopse"><h3>Sinopse</h3></label>
				<div class="divisor"></div>
						<textarea name="sinopse" class="inputs" id="sinopse"></textarea>
			<div class="divisor"></div>
						<label class="labels" for="lancamento"><h3>Lançamento</h3></label>
				<div class="divisor"></div>
						<input class="inputs" type="date" name="lancamento">
			<div class="divisor"></div>
						<label class="labels" for="comentario"><h3>Seu Comentário</h3></label>
				<div class="divisor"></div>
						<textarea name="comentario" id="comentario" class="inputs"></textarea>
			<div class="divisor"></div>
						<input id="enviar2" type="submit" name="enviar">
	</form>

<?php
include ("rodape.php");
?>