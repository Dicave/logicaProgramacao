<?php 

session_start();



session_destroy();

	//redireconar para a página inicial em zero segundos
	echo('<meta http-equiv="refresh" content="0;url=index.php">');



?>