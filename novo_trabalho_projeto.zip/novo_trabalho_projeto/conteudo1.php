<?php 
include("cabecalho.php");
?>
<section id="fundoconteudo">
	<section id="conteudo">
		<h2 id="titulocont" class="UpheavalPro">Mario</h2>
		<div class="divisor"></div>	
		<img src="imagens/mario.png" id="imgconteudo">
		<p id="textocont" align="justify">Mario, também conhecido como Super Mario, é um personagem fictício e o protagonista principal da série de videogames, criado pelo designer de jogos japonês Shigeru Miyamoto. Mario é o mascote oficial da Nintendo, e da FriendZone, sempre salvando a Princess Peach, por um beijo na bochecha tendo a sua aparição em mais de 80 jogos desde a sua criação. Embora, inicialmente, apenas aparecendo em jogos de plataforma, começando em Donkey Kong, Mario aparece atualmente em gêneros variados de videogames, tais como corrida, quebra-cabeça, RPG, luta, festa e esporte.</p>
	</section>
	<section id="conteudo2">
		<div class="divisor"></div>
		<b><h4 id="comentautor">Comentário do Autor:</h4></b>
		<br>
		<p id="textocoment" align="justify">Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod
		tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam,
		quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo
		consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse
		cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non
		proident, sunt in culpa qui officia deserunt mollit anim id est laborum.
		<br><br>
		Lançamento: 04/12/2001
		</p>
	</section>
	<div class="divisor"></div>

<div class="avaliacao">
			<h3 id="titulo_av">Avaliação Do Autor</h3>

			<link rel="stylesheet" href="//maxcdn.bootstrapcdn.com/font-awesome/4.3.0/css/font-awesome.min.css">
			<div class="estrelas">
			  <input type="radio" id="cm_star-empty" name="fb" value="" checked/>
			  <label for="cm_star-1"><i class="fa"></i></label>
			  <input type="radio" id="cm_star-1" name="fb" value="1"/>
			  <label for="cm_star-2"><i class="fa"></i></label>
			  <input type="radio" id="cm_star-2" name="fb" value="2"/>
			  <label for="cm_star-3"><i class="fa"></i></label>
			  <input type="radio" id="cm_star-3" name="fb" value="3"/>
			  <label for="cm_star-4"><i class="fa"></i></label>
			  <input type="radio" id="cm_star-4" name="fb" value="4"/>
			  <label for="cm_star-5"><i class="fa"></i></label>
			  <input type="radio" id="cm_star-5" name="fb" value="5"/>
			</div>
		</div>
<form method="$get">
		<div class="avaliacao2">
			<h3 id="titulo_av">Sua Avalição</h3>
			<a href="curtidas.php" ><label >Curtir</label></a>
			<input type="radio" name="curtir" value="1">
		</div>
</form>
	<div class="divisor"></div>

	
		<table id="tabela">
			<tr>
				<td><b>Usuários</td>
				<td><b>Comentários</td>
				<td></td>
			</tr>
			<tr>
				<td>Nome:</td>
				<td>

						<textarea id="mensagem" name="mensagem" rows=5 cols=20 wrap="off"></textarea>					
				
				</td>
				<td id="select">
					<form name="comentario" action="comentando.php" method="post">
						<select name="opcoes">
							<option>...</option>
							<option value="editar">editar</option>
							<option value="denunciar">denúnciar</option>
							<option value="excluir">excluir</option>
						</select>
			
						<input type="submit" name="enviar">
					</form>
				</td>
			</tr>

		</table>




<?php
include("rodape.php");
?>
</section>