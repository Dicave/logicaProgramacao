<?php
	session_start();
?>
<!DOCTYPE html>
<html>
<head>
    <link rel="stylesheet" type="text/css" href="css/bootstrap.min.css">
	<link rel="stylesheet" type="text/css" href="css/estilo.css">
	<title>Nostalgia</title>
</head>
<body id="corpo">
	<header  id="back">
        <?php
            if (	!isset($_SESSION['login'])) {
        ?>
		<form action="login.php" method="post" id="form">
			<label for="login" class="corlabel">login
			    <input type="text" name="login" id="inpute">
			</label>
            <br>
			<label for="senha" class="corlabel">senha
			    <input type="password" name="senha" id="inpute">
			</label>
				<br>
			<input type="submit" name="enviar" id="enviar">
			<div class="divisor"></div>
            <div>
                <a href="cadastro.php" id="cadastro">criar uma conta</a>
                <div class="divisor"></div>
                <a href="esqueceu.php" id="cadastro">esqueceu sua senha</a>
            </div>
		</form>
	<?php
		}else{
	?>
        <div id="form_logout">
			<h4 class=" corlabel">Você está logado como <?=$_SESSION['nome'] ?> !</h4>
            <a href="cadastroResenha.php" id="logout" class="corlabel">crie sua resenha</a>
            <div class="divisor"></div>
            <a href="logout.php" class="corlabel">sair</a>
		</div>
			<?php 
			}
			?>
		<img src="logos/logo.png" id="logo">
		<div class="divisor"></div>
		<nav id="menu">
			<a href="index.php"><section class="item_menu UpheavalPro col-xs-3"><h2>Home</h2></section></a>
			<a href="top5.php"><section class="item_menu UpheavalPro col-xs-3"><h2>Top 5</h2></section></a>
			<a href="resenhas.php"><section class="item_menu UpheavalPro col-xs-3"><h2>Resenhas</h2></section></a>
			<a href="suporte.php"><section class="item_menu UpheavalPro col-xs-3"><h2>Suporte Técnico</h2></section></a>
		</nav>
	</header>
