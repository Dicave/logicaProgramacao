<?php 
include("cabecalho.php");

$json_array=file_get_contents("dados/resenhas.json");

$lista_resenhas= json_decode($json_array,true);

$json = file_get_contents("dados/curtidas.json");

$lista_curtidas = json_decode($json,true);

// SÓ PUXEI AS INFORMAÇÕES QUE VAMOS USAR DO JSON//
// Eu consigo puxar a foto e os textos de cada resenhas mas coloca a estrutura e fala aonde que vai vc quer a foto e o texto que eu coloco//

	for ($i=0; $i <10 ; $i++) { 
		$curtidas[]=$lista_curtidas[$i]['numero_curtidas'];
			$posicoes[]=$lista_curtidas[$i]['id'];
				rsort($curtidas);
		}

// LOGO ACIMA ORDEI AS CURTIDAS DA MAIOR PARA A MENOR, EMBAIXO A UM ESPAÇO PARA COLOCA O HTML, PENSE QUE O FOR É SIMPLESMENTE UMA VARIAVEL//

?>

<!--COLOCA O HTML AQUI-->





<?php
	for ($i=0; $i <9 ; $i++) {

		if ($curtidas[0]==$lista_curtidas[$i]['numero_curtidas']) {
				$nome1 = $lista_curtidas[$i]['nome'];
                $lancamento1 = $lista_curtidas[$i]['lançamento'];
                $link1 = $lista_curtidas[$i]['link'];
				$id_primeiro=$i;

			}
		}
	//Logo abaixo feche a section ou sla oq tu vai usar pra colocar bonitinho isso e inicie a outra "section"//
?>

<!--COLOCA O HTML AQUI-->

<?php
	for ($i=0; $i <9 ; $i++) { 

		if ($curtidas[1]==$lista_curtidas[$i]['numero_curtidas']) {
            $nome2 = $lista_curtidas[$i]['nome'];
            $lancamento2 = $lista_curtidas[$i]['lançamento'];
            $link2 = $lista_curtidas[$i]['link'];
			$id_segundo=$i;


		}
	}
	//LEMBRANDO, TRATE CADA FOR COMO SE FOSSE SIMPLESMENTE UMA VARIAVEL 
?>


<!--COLOCA O HTML AQUI-->


<?php
	for ($i=0; $i <9 ; $i++) { 

		if ($curtidas[2]==$lista_curtidas[$i]['numero_curtidas']) {
            $nome3 = $lista_curtidas[$i]['nome'];
            $lancamento3 = $lista_curtidas[$i]['lançamento'];
            $link3 = $lista_curtidas[$i]['link'];
			$id_terceiro=$i;

		}
	}
?>

<!--COLOCA O HTML AQUI-->


<?php
	for ($i=0; $i <9 ; $i++) { 

		if ($curtidas[3]==$lista_curtidas[$i]['numero_curtidas']) {
            $nome4 = $lista_curtidas[$i]['nome'];
            $lancamento4 = $lista_curtidas[$i]['lançamento'];
            $link4 = $lista_curtidas[$i]['link'];
			$id_quarto=$i;

		}
	}
?>

<!--COLOCA O HTML AQUI-->


<?php
	for ($i=0; $i <9 ; $i++) { 

		if ($curtidas[4]==$lista_curtidas[$i]['numero_curtidas']) {
            $nome5 = $lista_curtidas[$i]['nome'];
            $lancamento5 = $lista_curtidas[$i]['lançamento'];
            $link5 = $lista_curtidas[$i]['link'];
			$id_quinto=$i;

		}
	}
?>

<!--ACABA O HTML AQUI-->
    <div class="container" id="conteudo">
        <h2 id="titulocont" class="UpheavalPro">Melhores Resenhas Avaliadas</h2>
        <div class="row">
            <div class="col-xs-12" >
                <div class="table-responsive">
                    <table class="table table-bordered table-striped table-hover table-condensed" >
                        <thead>
                        <tr class="active">
                            <th>Imagem</th>
                            <th>Nome</th>
                            <th>Lançamento</th>
                            <th>Link</th>
                        </tr>
                        </thead>
                        <tbody>
                        <tr class="success">
                            <td><img src="imagens/<?=$nome1 ?>.png" id="imgtable"></td>
                            <td><?=$nome1 ?></td>
                            <td><?=$lancamento1 ?></td>
                            <td><a href="<?=$link1 ?>">link para jogar</a> </td>
                        </tr>
                        <tr class="info">
                            <td><img src="imagens/<?=$nome2 ?>.png" id="imgtable"></td>
                            <td><?=$nome2 ?></td>
                            <td><?=$lancamento2 ?></td>
                            <td><a href="<?=$link2 ?>">link para jogar</a> </td>
                        </tr>
                        <tr class="warning">
                            <td><img src="imagens/<?=$nome3 ?>.png" id="imgtable"></td>
                            <td><?=$nome3 ?></td>
                            <td><?=$lancamento3 ?></td>
                            <td><a href="<?=$link3 ?>">link para jogar</a> </td>
                        </tr>
                        <tr class="danger">
                            <td><img src="imagens/<?=$nome4 ?>.png" id="imgtable"></td>
                            <td><?=$nome4 ?></td>
                            <td><?=$lancamento4 ?></td>
                            <td><a href="<?=$link4 ?>">link para jogar</a> </td>
                        </tr>
                        <tr>
                            <td><img src="imagens/<?=$nome5 ?>.png" id="imgtable"></td>
                            <td><?=$nome5 ?></td>
                            <td><?=$lancamento5 ?></td>
                            <td><a href="<?=$link5 ?>">link para jogar</a> </td>
                        </tr>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>

<?php
include("rodape.php");

 ?>