<?php 
include("cabecalho.php");
$json = file_get_contents('dados/resenhas.json');
$arrayInfo=json_decode($json,true);
$numero=$_GET["id"];
   $avaliacoes_json  = file_get_contents('dados/resenhas.json');
   $avaliacoes_array = json_decode($avaliacoes_json, true);
       if(isset($_GET['acao']) and $_GET['acao'] == "avaliar" and isset($_GET['nota'])){

        $avaliacoes_array['nota']=$_GET['nota'];

        $json = json_encode($avaliacoes_array, JSON_PRETTY_PRINT);
        file_put_contents("dados/resenhas.json", $json);    

    }


?>

	<div class="container" id="conteudo">
		<h2 id="titulocont" class="UpheavalPro"><?= $arrayInfo[$numero]["NomeResenha"] ?></h2>
		<div class="divisor"></div>
        <div class="row">
            <div class="col-xs-3">
		        <img src="imagens/<?= $arrayInfo[$numero]["NomeResenha"] ?>.png" id="imgconteudo">
                <p id="lancamento"><?= $arrayInfo[$numero]["lançamento"] ?></p>
            </div>
            <div class="col-xs-9">
		    <p id="textocont" align="justify"> <?= $arrayInfo[$numero]["Texto"]  ?> </p>
            </div>
        </div>
        <div class="divisor"></div>
        <div class="row">
            <div class="col-xs-7 col-xs-offset-3" <b><h4 id="comentautor">Comentário do Autor:</h4></b></div>
            <div class="col-xs-7 col-xs-offset-3" id="textocoment">
                <p align="justify"><?=$arrayInfo[$numero]["Comentario"] ?></p>
            </div>
        </div>

		<div class="divisor"></div>
            <div class="avaliacao2 col-xs-4">
            	 <h3 id="titulo_av">Avaliação Do Autor</h3>
 <li class="list-group-item">

                    <a class="estrela" href="conteudo.php?id=<?= $numero ?>&acao=avaliar&nota=1"> * </a>
                    <a class="estrela" href=".php?id=<?= $numero ?>&acao=avaliar&nota=2"> * </a>
                    <a class="estrela" href=".php?id=<?= $numero ?>&acao=avaliar&nota=3"> * </a>
                    <a class="estrela" href=".php?id=<?= $numero ?>&acao=avaliar&nota=4"> * </a>
                    <a class="estrela" href=".php?id=<?= $numero ?>&acao=avaliar&nota=5"> * </a>

  </li>


                <?php 
            if($numero==0){
               	if(isset($_GET['curtir'])and $_GET['curtir']==1){?>
                    <a href="descurtidas.php?id=1">Descutir</a>

                <?php }else{?>
                    <a href="curtidas.php?id=1&sera=curtir">Curtir</a>
                <?php 
            }

            	}elseif($numero==1){

            			if(isset($_GET['curtir'])and $_GET['curtir']==1){?>
                    <a href="descurtidas.php?id=2">Descutir</a>

                <?php }else{?>
                    <a href="curtidas.php?id=2&sera=curtir">Curtir</a>
                <?php 
            }

            	}elseif($numero==2) {
            		if(isset($_GET['curtir'])and $_GET['curtir']==1){?>
                    <a href="descurtidas.php?id=3">Descutir</a>

                <?php }else{?>
                    <a href="curtidas.php?id=3&sera=curtir">Curtir</a>
                <?php 
            }
            		
            	}elseif($numero==3) {
            		if(isset($_GET['curtir'])and $_GET['curtir']==1){?>
                    <a href="descurtidas.php?id=4">Descutir</a>

                <?php }else{?>
                    <a href="curtidas.php?id=4&sera=curtir">Curtir</a>
                <?php 
            }
        }elseif($numero==4) {
            		if(isset($_GET['curtir'])and $_GET['curtir']==1){?>
                    <a href="descurtidas.php?id=5">Descutir</a>

                <?php }else{?>
                    <a href="curtidas.php?id=5&sera=curtir">Curtir</a>
                <?php 
            }
        }elseif($numero==5) {
            		if(isset($_GET['curtir'])and $_GET['curtir']==1){?>
                    <a href="descurtidas.php?id=6">Descutir</a>

                <?php }else{?>
                    <a href="curtidas.php?id=6&sera=curtir">Curtir</a>
                <?php 
            }
        }elseif($numero==6) {
            		if(isset($_GET['curtir'])and $_GET['curtir']==1){?>
                    <a href="descurtidas.php?id=7">Descutir</a>

                <?php }else{?>
                    <a href="curtidas.php?id=7&sera=curtir">Curtir</a>
                <?php 
            }
        }elseif($numero==7) {
            		if(isset($_GET['curtir'])and $_GET['curtir']==1){?>
                    <a href="descurtidas.php?id=8">Descutir</a>

                <?php }else{?>
                    <a href="curtidas.php?id=8&sera=curtir">Curtir</a>
                <?php 
            }
        }elseif($numero==8) {
            		if(isset($_GET['curtir'])and $_GET['curtir']==1){?>
                    <a href="descurtidas.php?id=9">Descutir</a>

                <?php }else{?>
                    <a href="curtidas.php?id=9&sera=curtir">Curtir</a>
                <?php 
            }
        }elseif($numero==9) {
            		if(isset($_GET['curtir'])and $_GET['curtir']==1){?>
                    <a href="descurtidas.php?id=10">Descutir</a>

                <?php }
            }else{?>
                    <a href="curtidas.php?id=10&sera=curtir">Curtir</a>
                <?php 
            }
                ?>
            </div>
        </div>
    </div>
    <div class="divisor">
        
  <a href=" <?= $arrayInfo[$numero]["link"] ?>"> link zika</a>
    </div>
	<div class="divisor"></div>

	
		<table id="tabela">
			<tr>
				<td><b>Usuários</td>
				<td><b>Comentários</td>
				<td></td>
			</tr>
			<tr>
				<td>Nome:</td>
				<td>

						<textarea id="mensagem" name="mensagem" rows=5 cols=20 wrap="off"></textarea>					
				
				</td>
				<td id="select">
					<form name="comentario" action="comentando.php" method="post">
						<select name="opcoes">
							<option>opções</option>
							<option value="editar">editar</option>
							<option value="denunciar">denúnciar</option>
							<option value="excluir">excluir</option>
						</select>
			
						<input type="submit" name="enviar">
					</form>
				</td>
			</tr>

		</table>
<?php
include("rodape.php");
?>